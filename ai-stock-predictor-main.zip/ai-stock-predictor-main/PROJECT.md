# PROJECT.md — AI-Powered Stock Market Prediction & Analysis Platform

> **Single source of truth for Claude Code.** Build this project end-to-end following the spec below. Treat every section as binding requirements unless a section is explicitly labeled "Optional" or "Future".

---

## 1. Project Identity

**Name:** AI Stock Market Prediction & Analysis Platform
**Type:** Hybrid ML + Agentic AI system
**Level:** MCA major project / portfolio-grade
**Stack:** Python · XGBoost · yfinance · Streamlit · OpenRouter API

You are acting as a **senior AI/ML engineer + full-stack Python developer**. Build a production-style, modular, beginner-friendly system that combines a classical ML predictor with an LLM-powered analyst agent.

---

## 2. What This System Does (One-Paragraph Summary)

The system downloads historical stock data from Yahoo Finance, engineers technical indicators (RSI, MACD, SMA, EMA, Bollinger Bands, volume features), trains an **XGBoost classifier** to predict next-day BUY/SELL signals, and serves predictions through a **Streamlit dashboard**. Layered on top is an **AI agent** powered by the **OpenRouter API** that pulls news, runs sentiment analysis, explains every prediction in plain English, and answers user questions through a chat interface. **No database, no deep learning, no paid APIs required** — only CSV files, pickled models, and `.env` keys.

---

## 3. Hard Constraints (Non-Negotiable)

**MUST use:**
- XGBoost (classifier only)
- Yahoo Finance via `yfinance`
- CSV files + Pandas DataFrames for storage
- `joblib` / `pickle` for model persistence
- Streamlit for UI
- OpenRouter API for the AI agent layer

**MUST NOT use:**
- Any database (SQLite, Postgres, MongoDB — none)
- Deep learning (no LSTM, CNN, Transformers, neural nets)
- Random Forest, SVM, or other classifiers as the primary model
- Paid APIs (free tiers of NewsAPI / Tavily / DuckDuckGo are fine)
- Unnecessary microservices, Docker orchestration, or cloud infra

**Agent boundaries:**
- The AI agent **must not execute real trades**
- The AI agent **must not give guaranteed financial advice**
- All outputs must carry an educational disclaimer

---

## 4. Final Folder Structure

Create exactly this structure. Every file listed must exist and be functional.

```
stock-market-predictor/
│
├── data/
│   ├── raw_stock_data.csv          # downloaded OHLCV
│   └── processed_data.csv          # after feature engineering
│
├── models/
│   └── xgboost_model.pkl           # trained classifier
│
├── notebooks/
│   └── experimentation.ipynb       # EDA + experiments
│
├── src/                            # ML pipeline
│   ├── __init__.py
│   ├── data_loader.py
│   ├── features.py
│   ├── preprocess.py
│   ├── train_model.py
│   ├── predict.py
│   ├── evaluate.py
│   └── utils.py
│
├── ai_agent/                       # LLM agent layer
│   ├── __init__.py
│   ├── openrouter_client.py
│   ├── market_analyzer.py
│   ├── news_fetcher.py
│   ├── sentiment.py
│   ├── prompt_builder.py
│   └── ai_chat.py
│
├── dashboard/
│   └── app.py                      # Streamlit entry point
│
├── .env.example                    # template (commit this)
├── .env                            # actual keys (gitignore)
├── .gitignore
├── requirements.txt
├── README.md
└── main.py                         # orchestrates full pipeline
```

---

## 5. ML Pipeline Spec

### 5.1 Data Source
- **Tickers (default list):** `AAPL`, `TSLA`, `MSFT`, `AMZN`, `GOOG`
- **History:** 5 years
- **Interval:** daily (`1d`)
- Ticker list must be easy to edit (constant in `utils.py` or config dict).

### 5.2 Target Variable (Classification)

```
if Close[t+1] > Close[t]:
    target = 1   # BUY
else:
    target = 0   # SELL
```

### 5.3 Features

| Category   | Indicator                          | Library |
|------------|------------------------------------|---------|
| Momentum   | RSI (14), MACD (12/26/9)           | `ta`    |
| Trend      | SMA (20, 50), EMA (12, 26)         | `ta`    |
| Volatility | Bollinger Bands (20, 2σ)           | `ta`    |
| Volume     | raw Volume, Volume % change        | pandas  |

Drop NaN rows after indicator calculation. Save the cleaned frame to `data/processed_data.csv`.

### 5.4 Model Configuration

```python
from xgboost import XGBClassifier

model = XGBClassifier(
    n_estimators=200,
    learning_rate=0.05,
    max_depth=6,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=42,
    eval_metric="logloss",
)
```

### 5.5 Required Metrics

Print and save to console/log: **Accuracy, Precision, Recall, F1, Confusion Matrix**.

### 5.6 Module Responsibilities

| File                      | Responsibility                                                                                        |
|---------------------------|--------------------------------------------------------------------------------------------------------|
| `src/data_loader.py`      | Download via yfinance, save CSV, graceful error handling for invalid tickers / network issues          |
| `src/features.py`         | Compute all indicators, create target, drop NaNs, write processed CSV                                  |
| `src/preprocess.py`       | Column selection, optional scaling, **time-aware** train/test split (no random shuffle on time series) |
| `src/train_model.py`      | Fit XGBoost, print metrics, save `models/xgboost_model.pkl`                                            |
| `src/predict.py`          | Load model, predict latest row, return `{signal: BUY/SELL, confidence: 0.0–1.0}`                       |
| `src/evaluate.py`         | Confusion matrix plot, feature importance plot, actual-vs-predicted overlay                            |
| `src/utils.py`            | Constants (TICKERS, FEATURE_COLS), path helpers, logger setup                                          |

> ⚠️ **Time-series split note:** Use chronological split (e.g., first 80% train, last 20% test). Random `train_test_split` leaks future into the past.

---

## 6. AI Agent Layer Spec

### 6.1 Provider
**OpenRouter API** (single endpoint, many models). Read key from `.env`:

```
OPENROUTER_API_KEY=sk-or-...
NEWS_API_KEY=...           # optional, for news_fetcher
```

### 6.2 Recommended Models
- `deepseek/deepseek-chat` (cheap default)
- `openai/gpt-4o-mini`
- `anthropic/claude-3-haiku`
- `mistralai/mistral-small`

Make the model name configurable; default to `deepseek/deepseek-chat`.

### 6.3 Module Responsibilities

| File                              | Responsibility                                                                                                      |
|-----------------------------------|---------------------------------------------------------------------------------------------------------------------|
| `ai_agent/openrouter_client.py`   | Thin client: POST to `https://openrouter.ai/api/v1/chat/completions`, retry on 429/5xx with exponential backoff      |
| `ai_agent/news_fetcher.py`        | Fetch latest stock news (NewsAPI free tier OR DuckDuckGo search as fallback). Return list of `{title, summary, url}` |
| `ai_agent/sentiment.py`           | Score news with VADER (`vaderSentiment`) — bullish / bearish / neutral + compound score                              |
| `ai_agent/prompt_builder.py`      | Compose a structured prompt from indicators + prediction + news sentiment                                            |
| `ai_agent/market_analyzer.py`     | Orchestrate: pull features + prediction + news + sentiment → call OpenRouter → return Markdown analysis              |
| `ai_agent/ai_chat.py`             | Conversational interface — maintains short message history, calls OpenRouter, returns assistant reply                |

### 6.4 Prompt Template (Reference)

`prompt_builder.py` should produce something like:

```
You are a financial market analyst. Provide a CONCISE, EDUCATIONAL analysis.
You do NOT give financial advice or guarantees.

Stock: {TICKER}
Latest Close: {close}
RSI (14): {rsi}
MACD: {macd_state}
SMA(20) vs SMA(50): {sma_state}
Bollinger position: {bb_state}
Volume change: {vol_change}%

Model prediction: {BUY/SELL} (confidence {conf}%)

Recent news sentiment: {bullish/bearish/neutral} (score {score})
Top headlines:
- {headline_1}
- {headline_2}
- {headline_3}

Task:
1. Explain in 3-4 sentences WHY the model likely predicted {signal}.
2. Note one bullish factor and one bearish factor.
3. End with a one-line educational caveat.
```

### 6.5 Agent Output Style
- Concise (≤ 150 words for analysis, ≤ 80 for chat replies)
- Beginner-friendly, no jargon dumps
- Always end analyses with: *"Educational analysis only — not financial advice."*

---

## 7. Streamlit Dashboard Spec (`dashboard/app.py`)

### 7.1 Layout

**Sidebar:**
- Ticker dropdown (from `TICKERS`)
- Refresh data button
- LLM model selector (DeepSeek / GPT-4o-mini / Claude Haiku / Mistral)

**Main area — 4 sections in this order:**

1. **Price & Indicators**
   - Plotly candlestick (OHLC) + volume subplot
   - Overlay SMA20, SMA50, Bollinger upper/lower bands
   - Separate panels for RSI and MACD

2. **Prediction Card**
   - Big BUY / SELL badge (green / red)
   - Confidence % as progress bar
   - Last close price and date

3. **AI Market Analysis**
   - LLM-generated paragraph from `market_analyzer.py`
   - News headlines with sentiment chips (🟢 bullish / 🔴 bearish / ⚪ neutral)

4. **AI Chat Assistant**
   - `st.chat_input` + `st.chat_message`
   - Session-state history
   - Example starter questions as buttons: *"Why this prediction?"*, *"Explain RSI"*, *"Summarize today's news"*

### 7.2 UI Guidance
- Use `st.set_page_config(layout="wide")`
- Use `st.tabs` if vertical space gets tight
- Cache data calls with `@st.cache_data(ttl=3600)`
- Cache model load with `@st.cache_resource`

### 7.3 Feature Importance
Add an expander or tab showing the XGBoost feature importance bar chart from `evaluate.py`.

---

## 8. Pipeline Flow (End-to-End)

```
yfinance ──► raw_stock_data.csv
                 │
                 ▼
         features.py (indicators + target)
                 │
                 ▼
          processed_data.csv
                 │
                 ▼
       preprocess.py (split)
                 │
                 ▼
        train_model.py ──► xgboost_model.pkl
                 │
                 ▼
          predict.py ──► {signal, confidence}
                 │
                 ▼
    ┌────────────┴────────────┐
    ▼                         ▼
evaluate.py             ai_agent/market_analyzer.py
(plots, metrics)         │
                         ├── news_fetcher.py
                         ├── sentiment.py
                         ├── prompt_builder.py
                         └── openrouter_client.py
                                │
                                ▼
                       AI Markdown analysis
                                │
                                ▼
                       Streamlit dashboard
```

`main.py` should expose CLI commands:

```bash
python main.py download --ticker AAPL
python main.py features --ticker AAPL
python main.py train    --ticker AAPL
python main.py predict  --ticker AAPL
python main.py analyze  --ticker AAPL       # runs AI agent
streamlit run dashboard/app.py
```

Use `argparse` or `typer` (typer preferred for nicer help text).

---

## 9. `requirements.txt`

```
pandas
numpy
yfinance
xgboost
scikit-learn
matplotlib
plotly
streamlit
ta
joblib
python-dotenv
requests
vaderSentiment
typer
```

Pin versions only if needed for reproducibility — otherwise leave open for easy install.

---

## 10. `.env.example`

```
# OpenRouter — required for AI agent
OPENROUTER_API_KEY=

# Optional — falls back to DuckDuckGo if missing
NEWS_API_KEY=

# Optional overrides
DEFAULT_LLM_MODEL=deepseek/deepseek-chat
```

---

## 11. README.md Requirements

Generate a polished README containing, in order:
1. Project banner + one-line description
2. Features (bulleted)
3. Architecture diagram (ASCII or Mermaid)
4. Tech stack table
5. Folder structure (copy from §4)
6. Installation (clone → venv → pip install → set .env)
7. Usage (CLI commands + `streamlit run`)
8. How the XGBoost model works (3–4 paragraphs, beginner-friendly)
9. How the AI agent works (prompt flow diagram)
10. Screenshots section (placeholders: `![Dashboard](docs/dashboard.png)`)
11. Accuracy & limitations discussion (be honest — markets are noisy; ~52–58% accuracy is realistic)
12. Future improvements (copy §13 below)
13. Disclaimer + License (MIT)

---

## 12. Code Quality Bar

- **Modular:** one responsibility per file
- **Typed:** use type hints on public functions
- **Documented:** docstrings (Google or NumPy style) on every public function
- **Exception-safe:** wrap network and file I/O in try/except with informative messages
- **Logged:** use `logging` module, not `print` (except CLI summaries)
- **Beginner-readable:** prefer clarity over cleverness; comment non-obvious lines
- **Reproducible:** fix `random_state=42` everywhere relevant

---

## 13. Future Improvements (Document in README)

- Real-time prediction via WebSocket (yfinance live or Alpaca paper trading)
- Multi-stock portfolio dashboard with allocation suggestions
- Reinforcement learning agent for position sizing
- FinBERT-based sentiment instead of VADER
- Telegram / Discord alert bot for new signals
- Voice assistant front-end (Whisper + TTS)
- Multi-agent architecture (researcher + analyst + risk-manager agents)
- Backtesting engine with realistic transaction costs
- Auto-generated daily PDF reports
- Streaming news ingestion (Server-Sent Events)

---

## 14. Build Order for Claude Code

When implementing, build in this order so each step is testable:

1. `requirements.txt` + `.env.example` + `.gitignore`
2. `src/utils.py` (constants, paths, logger)
3. `src/data_loader.py` → test by downloading AAPL
4. `src/features.py` → test by generating processed CSV
5. `src/preprocess.py` → test split shapes
6. `src/train_model.py` → train and save `.pkl`, print metrics
7. `src/predict.py` → load model, predict latest
8. `src/evaluate.py` → plots
9. `ai_agent/openrouter_client.py` → test with a one-line ping
10. `ai_agent/news_fetcher.py` + `ai_agent/sentiment.py`
11. `ai_agent/prompt_builder.py` + `ai_agent/market_analyzer.py`
12. `ai_agent/ai_chat.py`
13. `dashboard/app.py` (wire everything together)
14. `main.py` CLI
15. `README.md` + `notebooks/experimentation.ipynb`

After each step, run a quick sanity check (a `__main__` block in the file is fine) before moving on.

---

## 15. Acceptance Checklist

Before declaring the project done, verify:

- [ ] `pip install -r requirements.txt` succeeds in a clean venv
- [ ] `python main.py train --ticker AAPL` produces `models/xgboost_model.pkl` and prints all 5 metrics
- [ ] `python main.py predict --ticker AAPL` outputs `{signal, confidence}`
- [ ] `streamlit run dashboard/app.py` opens without errors
- [ ] Candlestick + RSI + MACD render correctly
- [ ] BUY/SELL badge updates when ticker is changed
- [ ] AI analysis paragraph appears within ~5s
- [ ] Chat assistant responds to "Why this prediction?"
- [ ] News section shows ≥ 3 headlines with sentiment chips
- [ ] README screenshots placeholders exist
- [ ] `.env` is gitignored; `.env.example` is committed
- [ ] No database imports anywhere
- [ ] No deep-learning imports anywhere
- [ ] Disclaimer text present in dashboard footer and AI outputs

---

## 16. Disclaimer (Mandatory Footer in Dashboard)

> ⚠️ **This tool is for educational and academic purposes only.** Predictions are generated by a machine learning model and an AI language model; they are not financial advice. Past performance does not guarantee future results. Do your own research before making investment decisions.

---

**End of PROJECT.md** — Claude Code: implement section-by-section in the order given in §14. After each major section, briefly confirm completion before proceeding.