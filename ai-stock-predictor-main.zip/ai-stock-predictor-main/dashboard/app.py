"""Streamlit dashboard — ties the ML pipeline and AI agent together (§7).

Run with::

    streamlit run dashboard/app.py

Layout (§7.1): sidebar (ticker / refresh / LLM model) plus four main sections —
price & indicators, prediction card, AI market analysis, and an AI chat
assistant — followed by the mandatory educational disclaimer footer (§16).

Heavy work is cached: data downloads via ``@st.cache_data(ttl=3600)`` and model
loading via ``@st.cache_resource`` (§7.2). The rendering code lives in ``main()``
so the helper functions can be imported and tested without a browser.
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure the project root is importable when launched via `streamlit run`
# (Streamlit puts the script's own dir on sys.path, not the project root).
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from typing import Any, Optional

import pandas as pd
import plotly.graph_objects as go
import streamlit as st
from plotly.subplots import make_subplots

from ai_agent.ai_chat import AIChat
from ai_agent.market_analyzer import analyze_market
from src.data_loader import download_stock_data
from src.evaluate import plot_feature_importance
from src.features import build_features
from src.predict import load_model_bundle, predict_latest
from src.train_model import train_model
from src.utils import (
    AVAILABLE_LLM_MODELS,
    DASHBOARD_DISCLAIMER,
    DEFAULT_LLM_MODEL,
    TICKERS,
    get_market_info,
    market_status,
    next_session_info,
    next_trading_day,
)

# Ticker groups for the sidebar market selector (display layer only).
_INDEX_TICKERS = ("^NSEI", "^BSESN")
_TICKER_GROUPS: dict[str, list[str]] = {
    "US (NASDAQ)": [t for t in TICKERS if get_market_info(t)["exchange"] == "US" and t not in _INDEX_TICKERS],
    "India (NSE)": [t for t in TICKERS if t.endswith((".NS", ".BO"))],
    "Indices": list(_INDEX_TICKERS),
}


def _exchange_label(ticker: str) -> str:
    """Short exchange code for the caption (NASDAQ / NSE / BSE)."""
    if ticker.endswith(".BO") or ticker == "^BSESN":
        return "BSE"
    if ticker.endswith(".NS") or ticker == "^NSEI":
        return "NSE"
    return "NASDAQ"


def _close_label(ticker: str) -> str:
    """Human-readable close time for the trading-calendar list."""
    return "4:00 PM ET" if get_market_info(ticker)["exchange"] == "US" else "3:30 PM IST"


def _fmt_day(d: pd.Timestamp) -> str:
    """Format a date as 'Tue 2026-05-26'."""
    return d.strftime("%a %Y-%m-%d")


def status_pill(ticker: str, pred: dict) -> tuple[str, str]:
    """Return a (chip, text) status pill describing why the prediction is/ isn't moving.

    Compares the data's latest bar date (``pred['date']``) against the live
    market state so weekend/holiday "stuck on Friday" cases are unambiguous.
    """
    status = market_status(ticker)
    reason = status["reason"]
    last_session = status["last_session"]
    next_session = status["next_session"]
    today = pd.Timestamp.now(tz=status["timezone"]).normalize().tz_localize(None)
    last_close = pd.Timestamp(pred["date"])

    if reason == "open":
        if last_close >= today:
            return "🟢", "Live · Market open"
        return "🟡", f"Today's session in progress · prediction from {_fmt_day(last_close)} close"

    if reason == "after_hours":
        if last_close >= last_session:
            return "🟢", "Live · Closed for today"
        return "🟡", f"Session done · awaiting data update (last bar {_fmt_day(last_close)})"

    if reason == "weekend":
        info = next_session_info(ticker, today)
        note = ""
        if info["skipped_holidays"]:
            note = " · " + ", ".join(
                f"{name} ({d.strftime('%a')}) closed" for d, name in info["skipped_holidays"]
            )
        return "⚪", f"Weekend · Last session: {_fmt_day(last_session)} · Next: {_fmt_day(next_session)}{note}"

    if reason.startswith("holiday_"):
        name = reason.split("_", 1)[1]
        return "⚪", f"Holiday ({name}) · Next session: {_fmt_day(next_session)}"

    return "⚪", f"Market closed · Next session: {_fmt_day(next_session)}"


# --------------------------------------------------------------------------- #
# Cached data / model loaders (§7.2)
# --------------------------------------------------------------------------- #


@st.cache_data(ttl=3600, show_spinner="Downloading market data…")
def load_ticker_data(ticker: str) -> pd.DataFrame:
    """Download and feature-engineer data for a ticker (cached 1h).

    Args:
        ticker: Stock symbol.

    Returns:
        pd.DataFrame: Processed frame with OHLC, indicators, and target.
    """
    download_stock_data(ticker)
    return build_features(ticker)


@st.cache_resource(show_spinner="Loading model…")
def load_or_train_model(ticker: str) -> dict[str, Any]:
    """Load a ticker's model bundle, training it on demand if missing.

    Args:
        ticker: Stock symbol.

    Returns:
        dict: The model bundle (model, feature_cols, metrics, ...).
    """
    try:
        return load_model_bundle(ticker)
    except FileNotFoundError:
        load_ticker_data(ticker)  # guarantee processed CSV exists
        train_model(ticker)
        return load_model_bundle(ticker)


# --------------------------------------------------------------------------- #
# Pure view helpers (no Streamlit state — safe to unit test)
# --------------------------------------------------------------------------- #


def build_price_figure(df: pd.DataFrame) -> go.Figure:
    """Build the 4-panel price/volume/RSI/MACD figure (§7.1).

    Args:
        df: Processed frame with OHLC + indicator columns.

    Returns:
        go.Figure: Candlestick with SMA/Bollinger overlays, plus volume, RSI,
        and MACD subplots.
    """
    fig = make_subplots(
        rows=4,
        cols=1,
        shared_xaxes=True,
        vertical_spacing=0.03,
        row_heights=[0.5, 0.15, 0.175, 0.175],
        subplot_titles=("Price + SMA/Bollinger", "Volume", "RSI (14)", "MACD (12/26/9)"),
    )

    fig.add_trace(
        go.Candlestick(
            x=df["Date"], open=df["Open"], high=df["High"], low=df["Low"],
            close=df["Close"], name="OHLC",
        ),
        row=1, col=1,
    )
    fig.add_trace(go.Scatter(x=df["Date"], y=df["sma_20"], name="SMA20", line=dict(width=1)), row=1, col=1)
    fig.add_trace(go.Scatter(x=df["Date"], y=df["sma_50"], name="SMA50", line=dict(width=1)), row=1, col=1)
    fig.add_trace(
        go.Scatter(x=df["Date"], y=df["bb_high"], name="BB upper",
                   line=dict(width=1, dash="dot", color="gray")), row=1, col=1,
    )
    fig.add_trace(
        go.Scatter(x=df["Date"], y=df["bb_low"], name="BB lower",
                   line=dict(width=1, dash="dot", color="gray")), row=1, col=1,
    )

    fig.add_trace(go.Bar(x=df["Date"], y=df["volume"], name="Volume", marker_color="#9ecae1"), row=2, col=1)

    fig.add_trace(go.Scatter(x=df["Date"], y=df["rsi_14"], name="RSI", line=dict(color="#756bb1")), row=3, col=1)
    fig.add_hline(y=70, line_dash="dash", line_color="red", row=3, col=1)
    fig.add_hline(y=30, line_dash="dash", line_color="green", row=3, col=1)

    fig.add_trace(go.Scatter(x=df["Date"], y=df["macd"], name="MACD", line=dict(color="#2b8cbe")), row=4, col=1)
    fig.add_trace(go.Scatter(x=df["Date"], y=df["macd_signal"], name="Signal", line=dict(color="#fdae6b")), row=4, col=1)
    fig.add_trace(go.Bar(x=df["Date"], y=df["macd_diff"], name="Histogram", marker_color="#bdbdbd"), row=4, col=1)

    fig.update_layout(
        height=820,
        xaxis_rangeslider_visible=False,
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
        margin=dict(t=40, b=10, l=10, r=10),
    )
    return fig


# --------------------------------------------------------------------------- #
# Section renderers (use Streamlit)
# --------------------------------------------------------------------------- #


def render_prediction_card(pred: dict[str, Any], ticker: str, currency_symbol: str = "$") -> None:
    """Render the BUY/SELL badge, confidence bar, last close, and status pill (§7.1).

    Args:
        pred: Prediction dict from ``predict_latest``.
        ticker: Symbol, used to compute the market-status pill.
        currency_symbol: Currency prefix for the close price ("$" or "₹").
    """
    signal = pred["signal"]
    conf = float(pred["confidence"])
    color = "#1a9850" if signal == "BUY" else "#d73027"

    c1, c2, c3 = st.columns([1, 2, 2])
    c1.markdown(
        f"<div style='background:{color};color:white;padding:22px;border-radius:12px;"
        f"text-align:center;font-size:30px;font-weight:700'>{signal}</div>",
        unsafe_allow_html=True,
    )
    c2.metric("Confidence", f"{conf * 100:.0f}%")
    c2.progress(min(max(conf, 0.0), 1.0))
    c3.metric("Last Close", f"{currency_symbol}{pred['close']:.2f}")
    c3.caption(f"as of {pred['date']}")

    # Status pill: makes "market closed / waiting for next session" unambiguous.
    chip, text = status_pill(ticker, pred)
    pill_col, help_col = st.columns([5, 1])
    pill_col.markdown(
        f"<div style='display:inline-block;padding:6px 14px;border-radius:14px;"
        f"background:#f0f2f6;color:#262730;font-size:13px;margin-top:6px'>{chip} {text}</div>",
        unsafe_allow_html=True,
    )
    with help_col.popover("ℹ️ How updates work"):
        st.markdown(
            "**How predictions update**\n\n"
            "The model uses daily **closing** prices. Predictions update after each "
            "market close — not intraday, and not on weekends/holidays.\n\n"
            "- **US markets:** Mon–Fri, close 4:00 PM ET (≈1:30 AM IST next day)\n"
            "- **Indian markets:** Mon–Fri, close 3:30 PM IST\n\n"
            "If the prediction looks unchanged, it's because no new closing bar exists "
            "yet — the system being honest about real market activity."
        )


def render_news(analysis: dict[str, Any]) -> None:
    """Render the overall sentiment and headline list with chips (§7.1)."""
    sentiment = analysis.get("sentiment", {})
    st.markdown(
        f"**News sentiment:** {sentiment.get('overall_chip', '')} "
        f"{sentiment.get('overall_label', 'n/a')} "
        f"(score {sentiment.get('overall_score', 0)})"
    )
    items = sentiment.get("items", [])
    if not items:
        st.info("No recent headlines found.")
        return
    for h in items:
        title = h.get("title", "")
        url = h.get("url", "")
        chip = h.get("chip", "⚪")
        source = h.get("source", "")
        link = f"[{title}]({url})" if url else title
        st.markdown(f"{chip} {link}  \n<small>{source}</small>", unsafe_allow_html=True)


def render_chat(ticker: str, model: str, analysis: Optional[dict[str, Any]]) -> None:
    """Render the chat assistant with starter buttons and history (§7.1)."""
    if "chat" not in st.session_state:
        st.session_state.chat = AIChat(model=model)
    chat: AIChat = st.session_state.chat

    # Reset history when the ticker changes; keep model/context current.
    if st.session_state.get("chat_ticker") != ticker:
        chat.reset()
        st.session_state.chat_ticker = ticker
    chat.model = model
    if analysis:
        chat.set_context(AIChat.context_from_analysis(analysis))

    st.caption("Try a starter question:")
    cols = st.columns(3)
    starters = ["Why this prediction?", "Explain RSI", "Summarize today's news"]
    pending: Optional[str] = None
    for col, text in zip(cols, starters):
        if col.button(text, key=f"starter_{text}"):
            pending = text

    for msg in chat.history:
        with st.chat_message(msg["role"]):
            st.markdown(msg["content"])

    typed = st.chat_input("Ask about this stock…")
    if typed:
        pending = typed

    if pending:
        with st.spinner("Thinking…"):
            chat.ask(pending)
        st.rerun()


# --------------------------------------------------------------------------- #
# Main app
# --------------------------------------------------------------------------- #


def main() -> None:
    """Render the full dashboard."""
    st.set_page_config(page_title="AI Stock Predictor", page_icon="📈", layout="wide")
    st.title("AI Stock Market Prediction & Analysis")

    with st.sidebar:
        st.header("Controls")
        market = st.radio("Market", list(_TICKER_GROUPS.keys()), index=0)
        group = _TICKER_GROUPS[market]
        ticker = st.selectbox(
            "Ticker",
            group,
            index=0,
            format_func=lambda t: f"{TICKERS[t]} ({t})",
        )
        info = get_market_info(ticker)
        st.caption(f"{_exchange_label(ticker)} · {info['timezone']}")

        with st.expander("📅 Next 5 expected updates"):
            close_label = _close_label(ticker)
            day = market_status(ticker)["last_session"]
            for _ in range(5):
                day = next_trading_day(ticker, day)
                st.write(f"{_fmt_day(day)} · after {close_label}")

        model = st.selectbox(
            "LLM model",
            AVAILABLE_LLM_MODELS,
            index=AVAILABLE_LLM_MODELS.index(DEFAULT_LLM_MODEL),
        )
        if st.button("Refresh data"):
            load_ticker_data.clear()
            load_or_train_model.clear()
            st.rerun()

    # Data + model (with graceful failure).
    try:
        df = load_ticker_data(ticker)
        bundle = load_or_train_model(ticker)
    except Exception as exc:  # network / training failure
        st.error(f"Could not prepare data/model for {ticker}: {exc}")
        st.stop()

    # 1) Price & indicators
    st.subheader("1 · Price & Indicators")
    st.plotly_chart(build_price_figure(df), width="stretch")
    with st.expander("Feature importance (XGBoost)"):
        importance = dict(zip(bundle["feature_cols"], (float(v) for v in bundle["model"].feature_importances_)))
        st.pyplot(plot_feature_importance(importance))

    # 2) Prediction card
    st.subheader("2 · Prediction")
    pred = predict_latest(ticker, df=df, bundle=bundle)
    render_prediction_card(pred, ticker, currency_symbol=info["symbol"])

    # 3) AI market analysis
    st.subheader("3 · AI Market Analysis")
    analysis: Optional[dict[str, Any]] = None
    with st.spinner("Generating AI analysis…"):
        try:
            analysis = analyze_market(ticker, model=model)
        except Exception as exc:
            st.warning(f"AI analysis unavailable: {exc}")
    if analysis:
        st.markdown(analysis["analysis"])
        st.divider()
        render_news(analysis)

    # 4) AI chat assistant
    st.subheader("4 · AI Chat Assistant")
    render_chat(ticker, model, analysis)

    # Mandatory disclaimer footer (§16)
    st.divider()
    st.caption(DASHBOARD_DISCLAIMER)


if __name__ == "__main__":
    main()
