"""Command-line entry point orchestrating the full pipeline (§8).

Examples::

    python main.py download --ticker AAPL
    python main.py features --ticker AAPL
    python main.py train    --ticker AAPL
    python main.py predict  --ticker AAPL
    python main.py analyze  --ticker AAPL
    python main.py pipeline --ticker AAPL     # download -> features -> train -> predict

Uses ``typer`` for a friendly CLI. ``print`` is used here intentionally for
human-readable CLI summaries (internal flow still logs via the ``logging`` module).
"""

from __future__ import annotations

from typing import Optional

import pandas as pd
import typer

from ai_agent.market_analyzer import analyze_market
from src.data_loader import download_stock_data
from src.evaluate import evaluate_model
from src.features import build_features, load_processed_data
from src.predict import predict_latest, predict_live
from src.train_model import train_model
from src.utils import (
    TICKERS,
    enable_utf8_console,
    get_market_info,
    market_status,
    next_session_info,
)

app = typer.Typer(
    add_completion=False,
    help="AI Stock Market Prediction & Analysis Platform - pipeline CLI.",
)

# Reusable ticker option matching the spec's `--ticker AAPL` interface.
TickerOption = typer.Option("AAPL", "--ticker", "-t", help="Stock symbol, e.g. AAPL.")


@app.callback()
def _setup() -> None:
    """Run once before any command (ensures UTF-8 console output)."""
    enable_utf8_console()


def _validate_ticker(ticker: str) -> str:
    """Exit with a helpful message if the ticker is not in TICKERS."""
    if ticker not in TICKERS:
        typer.secho(f"Error: '{ticker}' is not a supported ticker.", fg=typer.colors.RED, err=True)
        typer.echo("Valid tickers:", err=True)
        for sym, name in TICKERS.items():
            typer.echo(f"  {sym:<14} {name}", err=True)
        raise typer.Exit(code=1)
    return ticker


def _ensure_processed(ticker: str) -> None:
    """Build the processed feature CSV from raw data if it is missing."""
    try:
        load_processed_data(ticker)
    except FileNotFoundError:
        print(f"[train] processed data missing for {ticker}; building features…")
        build_features(ticker)


@app.command()
def download(ticker: str = TickerOption) -> None:
    """Download raw OHLCV data from Yahoo Finance and save it as CSV."""
    _validate_ticker(ticker)
    df = download_stock_data(ticker)
    print(f"[download] {ticker}: {len(df)} rows "
          f"({df['Date'].min().date()} -> {df['Date'].max().date()})")


@app.command()
def features(ticker: str = TickerOption) -> None:
    """Engineer indicators + target and write the processed CSV."""
    _validate_ticker(ticker)
    df = build_features(ticker)
    print(f"[features] {ticker}: processed {df.shape[0]} rows x {df.shape[1]} cols")


@app.command()
def train(ticker: str = TickerOption) -> None:
    """Train the XGBoost classifier, print metrics, and save the model."""
    _validate_ticker(ticker)
    _ensure_processed(ticker)  # build features on demand if not done yet
    result = train_model(ticker)
    m = result.metrics
    print(f"[train] {ticker}: acc={m['accuracy']:.4f} prec={m['precision']:.4f} "
          f"recall={m['recall']:.4f} f1={m['f1']:.4f} (threshold={result.threshold})")
    print(f"[train] saved -> {', '.join(result.paths)}")


@app.command()
def predict(
    ticker: str = TickerOption,
    live: bool = typer.Option(
        True, "--live/--no-live",
        help="Download the latest real price before predicting (default). "
             "Use --no-live to predict from the saved CSV snapshot.",
    ),
) -> None:
    """Load the model and predict the latest BUY/SELL signal."""
    _validate_ticker(ticker)
    symbol = get_market_info(ticker)["symbol"]
    result = predict_live(ticker) if live else predict_latest(ticker)
    src = "live" if live else "cached"
    print(f"[predict] {ticker} @ {result['date']} close={symbol}{result['close']:.2f} ({src})")
    print(f"[predict] signal={result['signal']} confidence={result['confidence'] * 100:.1f}%")
    print(f"[predict] Status: {_status_caption(ticker, result['date'])}")


def _status_caption(ticker: str, last_close_date: str) -> str:
    """Build a human-readable market-status caption for the predict output.

    Distinguishes "this is the latest session" from "markets are closed and the
    prediction is honestly waiting for the next session" (weekend/holiday).
    """
    status = market_status(ticker)
    today = pd.Timestamp.now(tz=status["timezone"]).normalize().tz_localize(None)
    last_close = pd.Timestamp(last_close_date)

    if last_close >= today:
        return "Latest session. Prediction updates after next close."

    info = next_session_info(ticker, today)
    nxt = info["next_session"]
    note = ""
    if info["skipped_holidays"]:
        note = " (" + ", ".join(
            f"{name} holiday {d.strftime('%a')}" for d, name in info["skipped_holidays"]
        ) + ")"
    return (
        f"Markets closed since {last_close.strftime('%a %Y-%m-%d')}. "
        f"Next session: {nxt.strftime('%a %Y-%m-%d')}{note}. "
        f"Prediction will update after that session's close."
    )


@app.command()
def evaluate(ticker: str = TickerOption) -> None:
    """Generate evaluation plots (confusion / importance / actual-vs-predicted)."""
    _validate_ticker(ticker)
    out = evaluate_model(ticker)
    print(f"[evaluate] {ticker}: test accuracy {out['accuracy']:.4f}")
    for name, path in out["paths"].items():
        print(f"[evaluate] {name} -> {path}")


@app.command()
def analyze(
    ticker: str = TickerOption,
    model: Optional[str] = typer.Option(None, "--model", "-m", help="LLM model id."),
    refresh: bool = typer.Option(False, "--refresh", help="Bypass the response cache."),
) -> None:
    """Run the AI agent: prediction + news + sentiment + LLM analysis."""
    _validate_ticker(ticker)
    result = analyze_market(ticker, model=model, force_refresh=refresh)
    sent = result["sentiment"]
    print(f"[analyze] {ticker} @ {result['date']}: {result['signal']} "
          f"({result['confidence'] * 100:.0f}%) | sentiment {sent['overall_chip']} "
          f"{sent['overall_label']} | {'cached' if result['cached'] else 'fresh'}")
    print("\n" + result["analysis"])


@app.command()
def pipeline(ticker: str = TickerOption) -> None:
    """Run the full pipeline: download -> features -> train -> predict."""
    download(ticker)
    features(ticker)
    train(ticker)
    predict(ticker)
    print(f"[pipeline] {ticker}: complete.")


if __name__ == "__main__":
    app()
