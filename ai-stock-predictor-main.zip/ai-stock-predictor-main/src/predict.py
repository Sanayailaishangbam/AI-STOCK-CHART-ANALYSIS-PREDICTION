"""Load a trained model bundle and predict the latest BUY/SELL signal.

Loading uses ``joblib.load`` (never ``pickle.load``) per §12 — pickle can
execute arbitrary code on load, joblib does not. Feature computation is **not**
re-implemented here: the latest row comes from data produced by
``src.features`` (single source of truth), and columns are reordered to the
exact training order before scoring (XGBoost is positional).
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import joblib
import pandas as pd

from src.data_loader import download_stock_data
from src.features import build_features, load_processed_data
from src.utils import enable_utf8_console, get_logger, model_path

logger = get_logger(__name__)


def load_model_bundle(
    ticker: Optional[str] = None, path: Optional[Path] = None
) -> dict[str, Any]:
    """Load a persisted model bundle from disk via ``joblib``.

    Args:
        ticker: Symbol used to resolve the default model path (ignored if
            ``path`` is given).
        path: Explicit ``.pkl`` path overriding ``ticker``.

    Returns:
        dict: Bundle with keys ``model``, ``feature_cols``, ``ticker``,
        ``trained_at``, ``scaler``, ``metrics``.

    Raises:
        FileNotFoundError: If the model file does not exist.
        RuntimeError: If the file cannot be loaded or is malformed.
    """
    pkl_path = path or model_path(ticker)
    if not pkl_path.exists():
        raise FileNotFoundError(
            f"Model file not found: {pkl_path}. Train a model first."
        )
    try:
        # joblib.load — NOT pickle.load (safer, mandated by §12).
        bundle = joblib.load(pkl_path)
    except Exception as exc:
        raise RuntimeError(f"Could not load model bundle {pkl_path}: {exc}") from exc

    if not isinstance(bundle, dict) or "model" not in bundle or "feature_cols" not in bundle:
        raise RuntimeError(
            f"Malformed model bundle at {pkl_path}: expected dict with "
            f"'model' and 'feature_cols'."
        )
    logger.info("Loaded model bundle <- %s", pkl_path)
    return bundle


def predict_row(bundle: dict[str, Any], row: pd.DataFrame) -> dict[str, Any]:
    """Score a single feature row and return a BUY/SELL decision.

    The input is reindexed to the bundle's ``feature_cols`` order so the model
    receives columns in the exact order it was trained on. ``row`` must be a
    1-row DataFrame so the array passed to ``predict_proba`` is 2D ``(1, n)``.

    Args:
        bundle: Loaded model bundle.
        row: One-row DataFrame containing (at least) all feature columns.

    Returns:
        dict: ``{signal, confidence, proba_buy, proba_sell}`` where ``signal`` is
        ``"BUY"``/``"SELL"`` and ``confidence`` is the probability of the chosen
        class (0.0–1.0).

    Raises:
        ValueError: If ``row`` is not exactly one row or lacks feature columns.
    """
    if len(row) != 1:
        raise ValueError(f"Expected exactly one row, got {len(row)}.")

    feature_cols: list[str] = bundle["feature_cols"]
    missing = [c for c in feature_cols if c not in row.columns]
    if missing:
        raise ValueError(f"Input row missing feature columns: {missing}")

    # Enforce training column order (XGBoost is positional) and keep 2D shape.
    X = row[feature_cols]

    scaler = bundle.get("scaler")
    if scaler is not None:
        X = pd.DataFrame(scaler.transform(X), index=X.index, columns=feature_cols)

    model = bundle["model"]
    threshold = float(bundle.get("threshold", 0.5))
    proba = model.predict_proba(X)[0]  # [P(SELL), P(BUY)]
    proba_sell, proba_buy = float(proba[0]), float(proba[1])
    pred = int(proba_buy >= threshold)
    signal = "BUY" if pred == 1 else "SELL"
    confidence = proba_buy if pred == 1 else proba_sell

    return {
        "signal": signal,
        "confidence": round(confidence, 4),
        "proba_buy": round(proba_buy, 4),
        "proba_sell": round(proba_sell, 4),
        "threshold": round(threshold, 4),
    }


def predict_latest(
    ticker: Optional[str] = None,
    df: Optional[pd.DataFrame] = None,
    bundle: Optional[dict[str, Any]] = None,
    rebuild: bool = False,
) -> dict[str, Any]:
    """Predict the signal for the most recent available row of a ticker.

    Feature values come from ``src.features`` output (processed CSV by default,
    or freshly rebuilt when ``rebuild=True``) — never recomputed inline here.

    Args:
        ticker: Symbol to predict for.
        df: Optional pre-loaded processed frame (skips disk read).
        bundle: Optional pre-loaded model bundle (skips disk read).
        rebuild: If True, rebuild features from raw data instead of reading the
            processed CSV.

    Returns:
        dict: ``{ticker, date, close, signal, confidence, proba_buy, proba_sell}``.
    """
    if bundle is None:
        bundle = load_model_bundle(ticker)
    if df is None:
        df = build_features(ticker) if rebuild else load_processed_data(ticker)

    latest = df.iloc[[-1]]  # double brackets -> 1-row DataFrame (2D)
    result = predict_row(bundle, latest)

    latest_date = pd.to_datetime(latest["Date"].iloc[0]).date().isoformat()
    result.update(
        {
            "ticker": (ticker or bundle.get("ticker") or "").upper() or None,
            "date": latest_date,
            "close": round(float(latest["Close"].iloc[0]), 4),
        }
    )
    logger.info(
        "%s @ %s close=%.2f -> %s (conf %.1f%%)",
        result["ticker"],
        result["date"],
        result["close"],
        result["signal"],
        result["confidence"] * 100,
    )
    return result


def predict_live(
    ticker: str, bundle: Optional[dict[str, Any]] = None
) -> dict[str, Any]:
    """Download the freshest price, rebuild features, then predict the latest row.

    Use this when the prediction must reflect the **current real market price**
    rather than a previously saved CSV snapshot. Note that a new daily bar only
    exists after that exchange's session closes; on weekends/holidays this simply
    returns the most recent trading day's signal (the price has not changed).

    Args:
        ticker: Symbol to predict for.
        bundle: Optional pre-loaded model bundle (skips disk read).

    Returns:
        dict: Same shape as :func:`predict_latest`, computed on freshly
        downloaded data.
    """
    raw = download_stock_data(ticker)  # fresh from Yahoo Finance, saves CSV
    processed = build_features(ticker, raw_df=raw, save=True)
    return predict_latest(ticker, df=processed, bundle=bundle)


if __name__ == "__main__":
    enable_utf8_console()
    # Smoke test: predict AAPL's latest signal and verify the 4 safety checks.
    bundle = load_model_bundle("AAPL")
    processed = load_processed_data("AAPL")

    # Check #4: the array fed to predict_proba must be (1, n_features).
    feature_cols = bundle["feature_cols"]
    X = processed[feature_cols].iloc[[-1]]
    print("Input shape to predict_proba :", X.shape)
    print("Column order matches training:", list(X.columns) == feature_cols)

    result = predict_latest("AAPL", df=processed, bundle=bundle)
    print("\npredict_latest('AAPL') ->")
    for k, v in result.items():
        print(f"  {k:<11}: {v}")

    assert X.shape == (1, len(feature_cols))
    assert list(X.columns) == feature_cols
    assert result["signal"] in {"BUY", "SELL"}
    assert 0.0 <= result["confidence"] <= 1.0
    print("\npredict.py smoke test passed ✔")
