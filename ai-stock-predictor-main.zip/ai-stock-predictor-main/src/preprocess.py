"""Feature selection and time-aware train/test split.

Splitting is **strictly chronological** (first ``TRAIN_SPLIT`` fraction is train,
the remainder is test). A random ``train_test_split`` would leak future
information into the past, so it is deliberately avoided (§5.6).

Scaling is optional and off by default — XGBoost is scale-invariant — but a
``StandardScaler`` (fit on the training split only) is available when needed.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import pandas as pd
from sklearn.preprocessing import StandardScaler

from src.features import load_processed_data
from src.utils import (
    FEATURE_COLS,
    TARGET_COL,
    TRAIN_SPLIT,
    enable_utf8_console,
    get_logger,
)

logger = get_logger(__name__)


@dataclass
class SplitData:
    """Container for a chronological train/test split.

    Attributes:
        X_train: Training features (earliest rows).
        X_test: Test features (most recent rows).
        y_train: Training labels.
        y_test: Test labels.
        feature_cols: Ordered feature column names used.
        scaler: Fitted ``StandardScaler`` if scaling was applied, else ``None``.
    """

    X_train: pd.DataFrame
    X_test: pd.DataFrame
    y_train: pd.Series
    y_test: pd.Series
    feature_cols: list[str]
    scaler: Optional[StandardScaler] = None


def select_features(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series]:
    """Split a processed frame into the feature matrix ``X`` and target ``y``.

    Rows with a missing target (the final, future-unknown row) are dropped.

    Args:
        df: Processed frame containing ``FEATURE_COLS`` and ``TARGET_COL``.

    Returns:
        tuple: ``(X, y)`` where ``X`` is a DataFrame of features and ``y`` is an
        integer Series of labels, both re-indexed from 0 in chronological order.

    Raises:
        ValueError: If any required column is missing.
    """
    missing = [c for c in (*FEATURE_COLS, TARGET_COL) if c not in df.columns]
    if missing:
        raise ValueError(f"Processed data missing columns: {missing}")

    clean = df.dropna(subset=[TARGET_COL]).reset_index(drop=True)
    X = clean[FEATURE_COLS].copy()
    y = clean[TARGET_COL].astype(int)
    return X, y


def chronological_split(
    X: pd.DataFrame, y: pd.Series, train_frac: float = TRAIN_SPLIT
) -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """Split features/labels by time order — no shuffling (§5.6).

    The first ``train_frac`` of rows become the training set and the remaining
    (most recent) rows become the test set.

    Args:
        X: Feature matrix in chronological order.
        y: Labels aligned with ``X``.
        train_frac: Fraction of rows used for training (default ``0.8``).

    Returns:
        tuple: ``(X_train, X_test, y_train, y_test)``.

    Raises:
        ValueError: If ``train_frac`` is not in the open interval (0, 1) or the
            split would leave either side empty.
    """
    if not 0.0 < train_frac < 1.0:
        raise ValueError(f"train_frac must be in (0, 1), got {train_frac}")

    n = len(X)
    split_idx = int(n * train_frac)
    if split_idx == 0 or split_idx >= n:
        raise ValueError(
            f"Split produces an empty set (n={n}, train_frac={train_frac})."
        )

    X_train, X_test = X.iloc[:split_idx], X.iloc[split_idx:]
    y_train, y_test = y.iloc[:split_idx], y.iloc[split_idx:]
    logger.info(
        "Chronological split: train=%d (first %.0f%%), test=%d (last %.0f%%)",
        len(X_train),
        train_frac * 100,
        len(X_test),
        (1 - train_frac) * 100,
    )
    return X_train, X_test, y_train, y_test


def prepare_data(
    ticker: Optional[str] = None,
    df: Optional[pd.DataFrame] = None,
    train_frac: float = TRAIN_SPLIT,
    scale: bool = False,
) -> SplitData:
    """Load processed data and produce a ready-to-train chronological split.

    Args:
        ticker: Symbol used to locate the processed CSV (ignored if ``df`` given).
        df: Optional pre-loaded processed frame.
        train_frac: Fraction of rows used for training.
        scale: If True, fit a ``StandardScaler`` on the training split and apply
            it to both splits (column names preserved).

    Returns:
        SplitData: The split arrays plus metadata (and scaler if used).
    """
    if df is None:
        df = load_processed_data(ticker)

    X, y = select_features(df)
    X_train, X_test, y_train, y_test = chronological_split(X, y, train_frac)

    scaler: Optional[StandardScaler] = None
    if scale:
        scaler = StandardScaler()
        X_train = pd.DataFrame(
            scaler.fit_transform(X_train), index=X_train.index, columns=FEATURE_COLS
        )
        X_test = pd.DataFrame(
            scaler.transform(X_test), index=X_test.index, columns=FEATURE_COLS
        )
        logger.info("Applied StandardScaler (fit on train only)")

    return SplitData(
        X_train=X_train,
        X_test=X_test,
        y_train=y_train,
        y_test=y_test,
        feature_cols=list(FEATURE_COLS),
        scaler=scaler,
    )


if __name__ == "__main__":
    enable_utf8_console()
    # Smoke test: split AAPL and verify shapes + chronological ordering.
    processed = load_processed_data("AAPL")
    data = prepare_data(df=processed)

    print("\nX_train:", data.X_train.shape, " X_test:", data.X_test.shape)
    print("y_train:", data.y_train.shape, " y_test:", data.y_test.shape)
    print("Feature cols:", len(data.feature_cols))

    # Verify the test set is the most recent slice (no leakage).
    dates = processed.dropna(subset=[TARGET_COL]).reset_index(drop=True)["Date"]
    boundary = len(data.X_train)
    print("\nTrain last date :", dates.iloc[boundary - 1].date())
    print("Test  first date:", dates.iloc[boundary].date())
    print("Test  last  date:", dates.iloc[-1].date())
    assert dates.iloc[boundary - 1] < dates.iloc[boundary], "Train must precede test!"

    print("\nClass balance — train BUY%: {:.1%}, test BUY%: {:.1%}".format(
        data.y_train.mean(), data.y_test.mean()
    ))
    assert len(data.X_train) + len(data.X_test) == len(dates)
    print("\nSplit shapes consistent, chronology verified ✔")
