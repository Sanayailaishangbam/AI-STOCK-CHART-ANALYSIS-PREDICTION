"""ML pipeline package for the AI Stock Market Prediction & Analysis Platform."""
