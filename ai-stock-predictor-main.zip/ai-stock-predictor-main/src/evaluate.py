"""Evaluation plots: confusion matrix, feature importance, actual-vs-predicted.

Produces the three diagnostics named in §5.6 using matplotlib (headless ``Agg``
backend so it works under Streamlit and in CI). Each plotting function returns a
``matplotlib.figure.Figure`` so the dashboard can render it with ``st.pyplot``,
while :func:`evaluate_model` also writes PNGs to ``docs/``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Optional

import matplotlib

matplotlib.use("Agg")  # headless backend; safe under Streamlit / CLI

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.figure import Figure
from sklearn.metrics import confusion_matrix

from src.features import load_processed_data
from src.predict import load_model_bundle
from src.preprocess import prepare_data
from src.utils import TARGET_COL, docs_dir, enable_utf8_console, get_logger

logger = get_logger(__name__)

_CLASS_LABELS: list[str] = ["SELL", "BUY"]


def plot_confusion_matrix(
    cm: np.ndarray, labels: Optional[list[str]] = None
) -> Figure:
    """Render a confusion matrix as an annotated heatmap.

    Args:
        cm: 2x2 matrix ``[[TN, FP], [FN, TP]]``.
        labels: Class labels in index order (defaults to ``["SELL", "BUY"]``).

    Returns:
        Figure: The matplotlib figure.
    """
    labels = labels or _CLASS_LABELS
    fig, ax = plt.subplots(figsize=(4.5, 4))
    im = ax.imshow(cm, cmap="Blues")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    ax.set_xticks(range(len(labels)), labels=[f"Pred {l}" for l in labels])
    ax.set_yticks(range(len(labels)), labels=[f"Actual {l}" for l in labels])
    thresh = cm.max() / 2.0 if cm.max() else 0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(
                j,
                i,
                int(cm[i, j]),
                ha="center",
                va="center",
                color="white" if cm[i, j] > thresh else "black",
                fontsize=12,
            )
    ax.set_title("Confusion Matrix")
    fig.tight_layout()
    return fig


def plot_feature_importance(
    importance: dict[str, float], top_n: Optional[int] = None
) -> Figure:
    """Render an XGBoost feature-importance horizontal bar chart.

    Args:
        importance: Mapping of feature name -> importance score.
        top_n: If given, show only the top ``n`` features.

    Returns:
        Figure: The matplotlib figure.
    """
    items = sorted(importance.items(), key=lambda kv: kv[1], reverse=True)
    if top_n:
        items = items[:top_n]
    names = [k for k, _ in items][::-1]  # reverse so largest is on top
    values = [v for _, v in items][::-1]

    fig, ax = plt.subplots(figsize=(6, max(3, 0.35 * len(names))))
    ax.barh(names, values, color="#2b8cbe")
    ax.set_xlabel("Importance (gain-weighted)")
    ax.set_title("XGBoost Feature Importance")
    fig.tight_layout()
    return fig


def plot_actual_vs_predicted(
    dates: pd.Series, close: pd.Series, y_true: pd.Series, y_pred: np.ndarray
) -> Figure:
    """Overlay test-period close price with the model's BUY/SELL calls.

    Each test day is marked by the model's predicted signal; marker color shows
    whether that prediction matched the realized next-day direction (green =
    correct, red = wrong). This is the §5.6 actual-vs-predicted diagnostic.

    Args:
        dates: Test-period dates.
        close: Test-period close prices.
        y_true: Realized next-day direction labels.
        y_pred: Model-predicted labels.

    Returns:
        Figure: The matplotlib figure.
    """
    dates = pd.to_datetime(pd.Series(dates).reset_index(drop=True))
    close = pd.Series(close).reset_index(drop=True)
    y_true = pd.Series(y_true).reset_index(drop=True)
    y_pred = pd.Series(np.asarray(y_pred)).reset_index(drop=True)
    correct = y_true.to_numpy() == y_pred.to_numpy()

    fig, ax = plt.subplots(figsize=(10, 4.5))
    ax.plot(dates, close, color="#444", linewidth=1, label="Close", zorder=1)

    buy = y_pred == 1
    sell = y_pred == 0
    # Predicted BUY (up triangle) / SELL (down triangle); colored by correctness.
    ax.scatter(
        dates[buy], close[buy], marker="^", s=45, zorder=2,
        c=np.where(correct[buy.to_numpy()], "#2ca02c", "#d62728"),
        label="Pred BUY",
    )
    ax.scatter(
        dates[sell], close[sell], marker="v", s=45, zorder=2,
        c=np.where(correct[sell.to_numpy()], "#2ca02c", "#d62728"),
        label="Pred SELL",
    )
    acc = float(correct.mean()) if len(correct) else 0.0
    ax.set_title(f"Actual Price vs Predicted Signals (test accuracy {acc:.1%})")
    ax.set_ylabel("Close")
    ax.legend(loc="best", fontsize=8)
    fig.autofmt_xdate()
    fig.tight_layout()
    return fig


def evaluate_model(
    ticker: Optional[str] = None, save: bool = True
) -> dict[str, Any]:
    """Evaluate a saved model on its chronological test split and build plots.

    Args:
        ticker: Symbol whose model and processed data to evaluate.
        save: If True, write the three PNGs to ``docs/``.

    Returns:
        dict: ``{confusion, feature_importance, figures, paths, accuracy}``.
    """
    bundle = load_model_bundle(ticker)
    model = bundle["model"]
    feature_cols: list[str] = bundle["feature_cols"]

    df = load_processed_data(ticker)
    clean = df.dropna(subset=[TARGET_COL]).reset_index(drop=True)
    split = prepare_data(df=df)

    test_idx = split.X_test.index
    y_true = split.y_test
    # Use the bundle's tuned decision threshold so plots match training metrics.
    threshold = float(bundle.get("threshold", 0.5))
    proba = model.predict_proba(split.X_test[feature_cols])[:, 1]
    y_pred = (proba >= threshold).astype(int)

    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    importance = dict(zip(feature_cols, (float(v) for v in model.feature_importances_)))

    figures = {
        "confusion": plot_confusion_matrix(cm),
        "feature_importance": plot_feature_importance(importance),
        "actual_vs_predicted": plot_actual_vs_predicted(
            clean.loc[test_idx, "Date"], clean.loc[test_idx, "Close"], y_true, y_pred
        ),
    }

    paths: dict[str, str] = {}
    if save:
        tag = (ticker or "model").upper()
        for name, fig in figures.items():
            dest = docs_dir() / f"{tag}_{name}.png"
            try:
                fig.savefig(dest, dpi=110, bbox_inches="tight")
                paths[name] = str(dest)
                logger.info("Saved plot -> %s", dest)
            except OSError as exc:
                raise RuntimeError(f"Could not save plot {dest}: {exc}") from exc

    return {
        "confusion": cm,
        "feature_importance": importance,
        "figures": figures,
        "paths": paths,
        "accuracy": float((y_true.to_numpy() == y_pred).mean()),
    }


if __name__ == "__main__":
    enable_utf8_console()
    # Smoke test: evaluate the saved AAPL model and write the three plots.
    out = evaluate_model("AAPL")
    print("\nTest accuracy:", round(out["accuracy"], 4))
    print("Confusion matrix:\n", out["confusion"])
    print("\nPlots written:")
    for name, p in out["paths"].items():
        size = Path(p).stat().st_size if Path(p).exists() else 0
        print(f"  {name:<20}-> {p} ({size} bytes)")
    assert len(out["paths"]) == 3 and all(Path(p).exists() for p in out["paths"].values())
    plt.close("all")
    print("\nevaluate.py smoke test passed ✔")
