"""Train the XGBoost classifier, report metrics, and persist the model.

Fits an :class:`xgboost.XGBClassifier` (hyperparameters from ``utils.XGB_PARAMS``)
on the chronological training split, evaluates on the held-out (most recent)
test split, prints/logs Accuracy, Precision, Recall, F1, and the Confusion
Matrix (§5.5), then saves a model *bundle* with ``joblib`` (never bare pickle).

The bundle stores the fitted model plus the feature column order, ticker, and
metrics so that ``predict.py`` can score new rows without guessing column order.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from xgboost import XGBClassifier

from src.preprocess import SplitData, prepare_data
from src.utils import (
    FEATURE_COLS,
    XGB_PARAMS,
    enable_utf8_console,
    get_logger,
    model_path,
)

logger = get_logger(__name__)


@dataclass
class TrainResult:
    """Outcome of a training run.

    Attributes:
        model: The fitted XGBoost classifier.
        metrics: Dict of scalar metrics (accuracy/precision/recall/f1).
        confusion: 2x2 confusion matrix as ``[[TN, FP], [FN, TP]]``.
        feature_importance: Mapping of feature name -> importance (sorted desc).
        n_train: Number of training rows.
        n_test: Number of test rows.
        threshold: Decision threshold on P(BUY) used to convert probabilities
            into the BUY/SELL label (tuned on a validation slice).
        paths: List of files the bundle was written to.
    """

    model: XGBClassifier
    metrics: dict[str, float]
    confusion: np.ndarray
    feature_importance: dict[str, float]
    n_train: int
    n_test: int
    threshold: float = 0.5
    paths: list[str] = field(default_factory=list)


def compute_metrics(y_true: pd.Series, y_pred: np.ndarray) -> dict[str, float]:
    """Compute the five required classification metrics (scalars only).

    Args:
        y_true: Ground-truth labels.
        y_pred: Predicted labels.

    Returns:
        dict: ``accuracy``, ``precision``, ``recall``, ``f1`` (BUY = positive).
    """
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "f1": float(f1_score(y_true, y_pred, zero_division=0)),
    }


def tune_threshold(
    X_train: pd.DataFrame, y_train: pd.Series, params: dict, val_frac: float = 0.2
) -> float:
    """Pick a P(BUY) decision threshold that maximizes F1 on a validation slice.

    To avoid leaking the test set, a probe model is trained on the first part of
    the *training* data and the threshold is chosen on the held-out last
    ``val_frac`` of training rows (kept chronological — no shuffle). The returned
    threshold is then applied to the final model trained on the full training set.

    Args:
        X_train: Training features (chronological order).
        y_train: Training labels aligned with ``X_train``.
        params: XGBoost params for the probe model (the spec params).
        val_frac: Fraction of the training tail used as validation.

    Returns:
        float: Best threshold in [0.30, 0.70]; falls back to 0.5 if the split is
        too small or the validation slice has a single class.
    """
    n = len(X_train)
    k = int(n * (1 - val_frac))
    if k <= 0 or k >= n:
        return 0.5

    X_sub, X_val = X_train.iloc[:k], X_train.iloc[k:]
    y_sub, y_val = y_train.iloc[:k], y_train.iloc[k:]
    if y_val.nunique() < 2:
        return 0.5

    probe = XGBClassifier(**params)
    probe.fit(X_sub, y_sub)
    val_proba = probe.predict_proba(X_val)[:, 1]

    best_thr, best_f1 = 0.5, -1.0
    for thr in np.arange(0.30, 0.71, 0.02):
        f1 = f1_score(y_val, (val_proba >= thr).astype(int), zero_division=0)
        if f1 > best_f1:
            best_f1, best_thr = f1, round(float(thr), 2)
    logger.info("Tuned decision threshold = %.2f (val F1=%.3f)", best_thr, best_f1)
    return best_thr


def train_model(
    ticker: Optional[str] = None,
    df: Optional[pd.DataFrame] = None,
    split: Optional[SplitData] = None,
    save: bool = True,
) -> TrainResult:
    """Train and evaluate the XGBoost classifier for one ticker.

    Args:
        ticker: Symbol used to load data and name the model file.
        df: Optional pre-loaded processed frame (forwarded to ``prepare_data``).
        split: Optional pre-built :class:`SplitData` (skips loading/splitting).
        save: If True, persist the model bundle to disk.

    Returns:
        TrainResult: Fitted model, metrics, confusion matrix, importances, paths.
    """
    if split is None:
        split = prepare_data(ticker=ticker, df=df)

    logger.info(
        "Training XGBoost on %s (train=%d, test=%d)",
        ticker or "default",
        len(split.X_train),
        len(split.X_test),
    )

    # Tune the decision threshold on a validation slice BEFORE fitting the final
    # model, so the threshold never sees the test set (§5.4 params unchanged).
    threshold = tune_threshold(split.X_train, split.y_train, XGB_PARAMS)

    model = XGBClassifier(**XGB_PARAMS)
    model.fit(split.X_train, split.y_train)

    # Apply the tuned threshold to P(BUY) instead of the default 0.5.
    proba_test = model.predict_proba(split.X_test)[:, 1]
    y_pred = (proba_test >= threshold).astype(int)
    metrics = compute_metrics(split.y_test, y_pred)
    cm = confusion_matrix(split.y_test, y_pred, labels=[0, 1])

    importance = dict(
        sorted(
            zip(split.feature_cols, (float(v) for v in model.feature_importances_)),
            key=lambda kv: kv[1],
            reverse=True,
        )
    )

    _log_report(metrics, cm, threshold)

    paths: list[str] = []
    if save:
        bundle = {
            "model": model,
            "feature_cols": list(split.feature_cols),
            "ticker": ticker,
            "trained_at": datetime.now(timezone.utc).isoformat(),
            "scaler": split.scaler,
            "threshold": threshold,
            "metrics": metrics,
        }
        # Per-ticker file (ambiguity #3) + default alias for the spec's single file.
        targets = [model_path(ticker)]
        if ticker is not None:
            targets.append(model_path(None))
        for dest in targets:
            try:
                joblib.dump(bundle, dest)
                paths.append(str(dest))
                logger.info("Saved model bundle -> %s", dest)
            except OSError as exc:
                raise RuntimeError(f"Could not write model to {dest}: {exc}") from exc

    return TrainResult(
        model=model,
        metrics=metrics,
        confusion=cm,
        feature_importance=importance,
        n_train=len(split.X_train),
        n_test=len(split.X_test),
        threshold=threshold,
        paths=paths,
    )


def _log_report(metrics: dict[str, float], cm: np.ndarray, threshold: float = 0.5) -> None:
    """Print and log the five-metric block (§5.5).

    Args:
        metrics: Scalar metrics from :func:`compute_metrics`.
        cm: 2x2 confusion matrix ``[[TN, FP], [FN, TP]]``.
        threshold: Decision threshold used to produce the predictions.
    """
    lines = [
        "================ Model Evaluation ================",
        f"Decision threshold (P(BUY) >=): {threshold:.2f}",
        f"Accuracy : {metrics['accuracy']:.4f}",
        f"Precision: {metrics['precision']:.4f}  (BUY = positive class)",
        f"Recall   : {metrics['recall']:.4f}",
        f"F1 Score : {metrics['f1']:.4f}",
        "Confusion Matrix:",
        "                 Pred SELL   Pred BUY",
        f"  Actual SELL      {cm[0, 0]:>6d}     {cm[0, 1]:>6d}",
        f"  Actual BUY       {cm[1, 0]:>6d}     {cm[1, 1]:>6d}",
        "==================================================",
    ]
    report = "\n".join(lines)
    logger.info("Evaluation complete")
    print(report)


if __name__ == "__main__":
    enable_utf8_console()
    # Smoke test: train on AAPL processed data and report everything.
    result = train_model("AAPL")

    print("\nSplit sizes -> train:", result.n_train, " test:", result.n_test)
    print("Tuned threshold:", result.threshold)
    print("\nTop 5 features by importance:")
    for i, (name, imp) in enumerate(list(result.feature_importance.items())[:5], 1):
        print(f"  {i}. {name:<18} {imp:.4f}")
    print("\nModel files written:")
    for p in result.paths:
        print("  -", p)

    assert 0.0 <= result.metrics["accuracy"] <= 1.0
    assert all(model_file for model_file in result.paths)
    print("\ntrain_model.py smoke test passed ✔")
