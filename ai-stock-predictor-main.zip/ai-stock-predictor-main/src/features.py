"""Feature engineering: technical indicators + next-day classification target.

Computes the indicators listed in §5.3 using the ``ta`` library, derives the
BUY/SELL target (§5.2), drops indicator warm-up NaNs, and writes the cleaned
frame to ``data/processed_<TICKER>.csv``.

The final row is intentionally retained even though its target is undefined
(no ``t+1`` close exists yet) so that live prediction can use its features.
``preprocess.py`` is responsible for dropping the NaN-target row before training.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd
from ta.momentum import RSIIndicator
from ta.trend import EMAIndicator, MACD, SMAIndicator
from ta.volatility import BollingerBands

from src.data_loader import load_raw_data
from src.utils import (
    FEATURE_COLS,
    TARGET_COL,
    get_logger,
    processed_data_path,
)

logger = get_logger(__name__)

#: OHLCV/context columns kept alongside features for the dashboard & display.
_KEEP_COLS: list[str] = ["Date", "Open", "High", "Low", "Close"]


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """Add all technical-indicator feature columns to a copy of ``df``.

    Indicators (§5.3): RSI(14); MACD(12/26/9); SMA(20,50); EMA(12,26);
    Bollinger Bands(20, 2σ) high/low/width/%B; raw Volume and its % change.

    Args:
        df: Frame containing at least ``Close`` and ``Volume`` columns.

    Returns:
        pd.DataFrame: A new frame with the indicator columns appended.
    """
    df = df.copy()
    close = df["Close"]

    # Momentum
    df["rsi_14"] = RSIIndicator(close=close, window=14).rsi()
    macd = MACD(close=close, window_slow=26, window_fast=12, window_sign=9)
    df["macd"] = macd.macd()
    df["macd_signal"] = macd.macd_signal()
    df["macd_diff"] = macd.macd_diff()

    # Trend
    df["sma_20"] = SMAIndicator(close=close, window=20).sma_indicator()
    df["sma_50"] = SMAIndicator(close=close, window=50).sma_indicator()
    df["ema_12"] = EMAIndicator(close=close, window=12).ema_indicator()
    df["ema_26"] = EMAIndicator(close=close, window=26).ema_indicator()

    # Volatility — Bollinger Bands (20, 2σ)
    bb = BollingerBands(close=close, window=20, window_dev=2)
    df["bb_high"] = bb.bollinger_hband()
    df["bb_low"] = bb.bollinger_lband()
    df["bb_width"] = bb.bollinger_wband()  # band width (%)
    df["bb_pband"] = bb.bollinger_pband()  # %B: position within the bands

    # Volume
    df["volume"] = df["Volume"]
    df["volume_pct_change"] = df["Volume"].pct_change()

    return df


def add_target(df: pd.DataFrame) -> pd.DataFrame:
    """Add the next-day BUY/SELL target column (§5.2).

    ``target = 1`` if tomorrow's close is higher than today's, else ``0``.
    The final row's target is ``NaN`` because no ``t+1`` close exists.

    Args:
        df: Frame containing a ``Close`` column, ordered chronologically.

    Returns:
        pd.DataFrame: A new frame with a float ``target`` column added.
    """
    df = df.copy()
    next_close = df["Close"].shift(-1)
    target = (next_close > df["Close"]).astype("float64")
    target[next_close.isna()] = pd.NA  # undefined for the last row
    df[TARGET_COL] = target
    return df


def build_features(
    ticker: Optional[str] = None,
    raw_df: Optional[pd.DataFrame] = None,
    save: bool = True,
) -> pd.DataFrame:
    """Build the processed feature frame for one ticker.

    Loads raw data (unless ``raw_df`` is supplied), sorts chronologically, adds
    indicators and the target, drops warm-up rows where any feature is NaN, and
    optionally writes ``data/processed_<TICKER>.csv``.

    Args:
        ticker: Symbol used to locate raw input and name the output file.
        raw_df: Optional pre-loaded raw OHLCV frame (skips disk read).
        save: If True, write the processed CSV.

    Returns:
        pd.DataFrame: Processed frame with OHLC context, features, and target.

    Raises:
        ValueError: If required input columns are missing.
        RuntimeError: If the processed CSV cannot be written.
    """
    df = raw_df.copy() if raw_df is not None else load_raw_data(ticker)

    required = {"Date", "Close", "Volume"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Raw data missing required columns: {sorted(missing)}")

    df["Date"] = pd.to_datetime(df["Date"])
    df = df.sort_values("Date").reset_index(drop=True)

    df = add_indicators(df)
    df = add_target(df)

    # Zero-volume days (seen on some Indian symbols/indices) make
    # ``volume_pct_change`` divide by zero -> ±inf, which XGBoost rejects.
    # Treat inf as missing so those rows are dropped alongside warm-up NaNs.
    df[FEATURE_COLS] = df[FEATURE_COLS].replace([np.inf, -np.inf], np.nan)

    before = len(df)
    # Drop indicator warm-up rows only; the NaN-target final row is preserved
    # because its features are valid and needed for live prediction.
    df = df.dropna(subset=FEATURE_COLS).reset_index(drop=True)
    logger.info("Dropped %d warm-up rows (%d -> %d)", before - len(df), before, len(df))

    ordered_cols = [*_KEEP_COLS, *FEATURE_COLS, TARGET_COL]
    df = df[[c for c in ordered_cols if c in df.columns]]

    if save:
        dest = processed_data_path(ticker)
        try:
            df.to_csv(dest, index=False)
            logger.info("Saved processed data -> %s", dest)
        except OSError as exc:
            raise RuntimeError(f"Could not write processed CSV to {dest}: {exc}") from exc

    return df


def load_processed_data(
    ticker: Optional[str] = None, path: Optional[Path] = None
) -> pd.DataFrame:
    """Load a previously generated processed CSV.

    Args:
        ticker: Symbol used to resolve the default path (ignored if ``path`` given).
        path: Explicit CSV path overriding ``ticker``.

    Returns:
        pd.DataFrame: Processed frame with a parsed ``Date`` column.

    Raises:
        FileNotFoundError: If the CSV does not exist.
        RuntimeError: If the file cannot be read.
    """
    csv_path = path or processed_data_path(ticker)
    if not csv_path.exists():
        raise FileNotFoundError(
            f"Processed data file not found: {csv_path}. Run feature engineering first."
        )
    try:
        return pd.read_csv(csv_path, parse_dates=["Date"])
    except Exception as exc:
        raise RuntimeError(f"Could not read processed CSV {csv_path}: {exc}") from exc


if __name__ == "__main__":
    # Smoke test: build features for AAPL from the raw CSV saved in Step 3.
    out = build_features("AAPL")
    print("\nProcessed shape:", out.shape)
    print("Columns:", list(out.columns))
    print("\nNaN per column:\n", out.isna().sum().to_string())
    tgt = out[TARGET_COL].dropna()
    print("\nTarget distribution (excl. last row):")
    print(tgt.value_counts().to_string())
    print(f"BUY share: {tgt.mean():.1%}")
    print("\nLast row target (should be NaN/empty):", out[TARGET_COL].iloc[-1])
    print("\nTail (selected cols):")
    print(out[["Date", "Close", "rsi_14", "macd_diff", "bb_pband", "target"]].tail(3).to_string(index=False))
