"""Download historical OHLCV data from Yahoo Finance and persist it as CSV.

Uses ``yfinance`` only (per §3) and stores results under ``data/`` as plain
CSV — no database. All network and file I/O is wrapped with informative error
handling so callers get clear messages on invalid tickers or connectivity loss.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import pandas as pd
import yfinance as yf

from src.utils import (
    DATA_INTERVAL,
    HISTORY_PERIOD,
    get_logger,
    raw_data_path,
)

logger = get_logger(__name__)

#: Columns we keep from the yfinance response (drop Dividends / Stock Splits).
_OHLCV_COLS: list[str] = ["Open", "High", "Low", "Close", "Volume"]


def _flatten_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Flatten a possible MultiIndex column frame to single-level names.

    Some yfinance code paths return a ``(field, ticker)`` MultiIndex even for a
    single symbol. We keep only the field level so downstream code sees plain
    ``Open/High/Low/Close/Volume`` columns.

    Args:
        df: Frame whose columns may be a MultiIndex.

    Returns:
        pd.DataFrame: Frame with single-level column names.
    """
    if isinstance(df.columns, pd.MultiIndex):
        df = df.copy()
        df.columns = df.columns.get_level_values(0)
    return df


def download_stock_data(
    ticker: str,
    period: str = HISTORY_PERIOD,
    interval: str = DATA_INTERVAL,
    save: bool = True,
) -> pd.DataFrame:
    """Download historical OHLCV data for a single ticker.

    Args:
        ticker: Stock symbol, e.g. ``"AAPL"``.
        period: yfinance period string (default ``"5y"``).
        interval: Candle interval (default ``"1d"``).
        save: If True, write the result to ``data/raw_<TICKER>.csv``.

    Returns:
        pd.DataFrame: Columns ``Date, Open, High, Low, Close, Volume`` with a
        clean ``RangeIndex``.

    Raises:
        ValueError: If ``ticker`` is empty or the download returns no rows
            (invalid symbol or no data for the period).
        RuntimeError: If the network call to Yahoo Finance fails.
    """
    if not ticker or not ticker.strip():
        raise ValueError("Ticker must be a non-empty string.")
    ticker = ticker.strip().upper()

    logger.info("Downloading %s (period=%s, interval=%s)", ticker, period, interval)
    try:
        # Ticker.history() yields single-level columns and a Date index, and
        # auto-adjusts OHLC by default — cleaner than yf.download for one symbol.
        raw = yf.Ticker(ticker).history(period=period, interval=interval)
    except Exception as exc:  # network / yfinance internal errors
        raise RuntimeError(
            f"Failed to download {ticker} from Yahoo Finance: {exc}"
        ) from exc

    if raw is None or raw.empty:
        raise ValueError(
            f"No data returned for '{ticker}'. The symbol may be invalid or "
            f"there may be no data for period='{period}'."
        )

    raw = _flatten_columns(raw)

    missing = [c for c in _OHLCV_COLS if c not in raw.columns]
    if missing:
        raise ValueError(f"Downloaded data for {ticker} is missing columns: {missing}")

    df = raw.reset_index()[["Date", *_OHLCV_COLS]].copy()
    # Normalize the Date column to a tz-naive date for stable CSV round-trips.
    df["Date"] = pd.to_datetime(df["Date"]).dt.tz_localize(None)

    logger.info("Downloaded %d rows for %s", len(df), ticker)
    if len(df) < 500:
        # Indian indices/stocks occasionally return short histories or have gaps.
        logger.warning(
            "Only %d rows for %s (<500). Indicators and the time-split may be "
            "unreliable; check the symbol or history availability.",
            len(df),
            ticker,
        )

    if save:
        dest = raw_data_path(ticker)
        try:
            df.to_csv(dest, index=False)
            logger.info("Saved raw data -> %s", dest)
        except OSError as exc:
            raise RuntimeError(f"Could not write raw CSV to {dest}: {exc}") from exc

    return df


def load_raw_data(ticker: Optional[str] = None, path: Optional[Path] = None) -> pd.DataFrame:
    """Load previously downloaded raw OHLCV data from CSV.

    Args:
        ticker: Symbol used to resolve the default path (ignored if ``path`` is given).
        path: Explicit CSV path. Overrides ``ticker`` when provided.

    Returns:
        pd.DataFrame: Raw OHLCV frame with a parsed ``Date`` column.

    Raises:
        FileNotFoundError: If the CSV does not exist.
        RuntimeError: If the file exists but cannot be read.
    """
    csv_path = path or raw_data_path(ticker)
    if not csv_path.exists():
        raise FileNotFoundError(
            f"Raw data file not found: {csv_path}. Run a download first."
        )
    try:
        return pd.read_csv(csv_path, parse_dates=["Date"])
    except Exception as exc:
        raise RuntimeError(f"Could not read raw CSV {csv_path}: {exc}") from exc


if __name__ == "__main__":
    # Smoke test: download AAPL and show a quick summary.
    df = download_stock_data("AAPL")
    print("\nShape:", df.shape)
    print("Columns:", list(df.columns))
    print("Date range:", df["Date"].min().date(), "->", df["Date"].max().date())
    print("\nHead:\n", df.head(3).to_string(index=False))
    print("\nTail:\n", df.tail(3).to_string(index=False))
    print("\nSaved to:", raw_data_path("AAPL"))
