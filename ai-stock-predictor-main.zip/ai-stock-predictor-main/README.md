# AI Stock Market Prediction & Analysis Platform

> A hybrid **machine-learning + agentic-AI** system that predicts next-day BUY/SELL signals with an XGBoost classifier and explains them in plain English using an LLM analyst — all served through an interactive Streamlit dashboard.

---

## Features

- **Historical data ingestion** from Yahoo Finance (`yfinance`) — 5 years of daily OHLCV, stored as CSV (no database).
- **Technical feature engineering** — RSI, MACD, SMA(20/50), EMA(12/26), Bollinger Bands, and volume features via the `ta` library.
- **XGBoost classifier** predicting next-day direction (BUY = up, SELL = down) with a strictly **chronological** train/test split (no future leakage).
- **AI analyst agent** (OpenRouter) that fetches news, scores sentiment with VADER, and produces a concise, beginner-friendly explanation of each prediction.
- **Conversational chat assistant** grounded in the current prediction and indicators.
- **Streamlit dashboard** with an interactive Plotly candlestick (SMA/Bollinger overlays), RSI & MACD panels, a BUY/SELL prediction card, AI analysis, sentiment-tagged headlines, and a chat box.
- **Response caching** by `(ticker, date, model)` so repeated runs don't burn API credits.
- **Typer CLI** to run any pipeline stage from the terminal.

---

## Architecture

```
yfinance ──► raw_stock_data.csv
                 │
                 ▼
        features.py (indicators + next-day target)
                 │
                 ▼
          processed_data.csv
                 │
                 ▼
       preprocess.py (chronological split)
                 │
                 ▼
        train_model.py ──► models/xgboost_<TICKER>.pkl
                 │
                 ▼
          predict.py ──► {signal, confidence}
                 │
     ┌───────────┴───────────────┐
     ▼                           ▼
 evaluate.py            ai_agent/market_analyzer.py
 (plots, metrics)        ├── news_fetcher.py  (NewsAPI / DuckDuckGo)
                         ├── sentiment.py     (VADER)
                         ├── prompt_builder.py
                         └── openrouter_client.py
                                │
                                ▼
                       AI Markdown analysis
                                │
                                ▼
                    Streamlit dashboard (dashboard/app.py)
```

---

## Tech Stack

| Layer            | Tools |
|------------------|-------|
| Language         | Python 3.14 |
| ML model         | XGBoost (`XGBClassifier`) |
| Data             | yfinance, pandas, numpy, CSV |
| Indicators       | `ta` |
| Split / metrics  | scikit-learn |
| Plots            | Plotly (dashboard), matplotlib (evaluation) |
| UI               | Streamlit |
| LLM provider     | OpenRouter (default `deepseek/deepseek-chat`) |
| News             | NewsAPI (optional) → DuckDuckGo (`ddgs`) fallback |
| Sentiment        | `vaderSentiment` |
| Model persistence| `joblib` |
| Config / secrets | `python-dotenv` |
| CLI              | `typer` |

---

## Folder Structure

```
stock-market-predictor/
│
├── data/
│   ├── raw_stock_data.csv          # downloaded OHLCV
│   └── processed_data.csv          # after feature engineering
│
├── models/
│   └── xgboost_model.pkl           # trained classifier
│
├── notebooks/
│   └── experimentation.ipynb       # EDA + experiments
│
├── src/                            # ML pipeline
│   ├── __init__.py
│   ├── data_loader.py
│   ├── features.py
│   ├── preprocess.py
│   ├── train_model.py
│   ├── predict.py
│   ├── evaluate.py
│   └── utils.py
│
├── ai_agent/                       # LLM agent layer
│   ├── __init__.py
│   ├── openrouter_client.py
│   ├── market_analyzer.py
│   ├── news_fetcher.py
│   ├── sentiment.py
│   ├── prompt_builder.py
│   └── ai_chat.py
│
├── dashboard/
│   └── app.py                      # Streamlit entry point
│
├── .env.example                    # template (commit this)
├── .env                            # actual keys (gitignored)
├── .gitignore
├── requirements.txt
├── README.md
└── main.py                         # orchestrates full pipeline
```

> Note: data, model, and processed files are saved **per ticker** (e.g. `raw_AAPL.csv`,
> `xgboost_AAPL.pkl`); the spec's default single-file names are also supported as a fallback.

---

## Installation

```bash
# 1. Clone
git clone <your-repo-url> stock-market-predictor
cd stock-market-predictor

# 2. Create and activate a virtual environment
python -m venv myvenv
# Windows
myvenv\Scripts\activate
# macOS / Linux
source myvenv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure secrets
cp .env.example .env          # Windows: copy .env.example .env
#   then edit .env and set OPENROUTER_API_KEY=sk-or-...
```

`.env` keys:

```
OPENROUTER_API_KEY=sk-or-...   # required for the AI agent
NEWS_API_KEY=                  # optional; falls back to DuckDuckGo if empty
DEFAULT_LLM_MODEL=deepseek/deepseek-chat
```

---

## Usage

### CLI (`main.py`)

```bash
python main.py download --ticker AAPL     # download OHLCV
python main.py features --ticker AAPL     # engineer indicators + target
python main.py train    --ticker AAPL     # train XGBoost, print metrics, save model
python main.py predict  --ticker AAPL     # latest BUY/SELL + confidence
python main.py evaluate --ticker AAPL     # confusion / importance / actual-vs-predicted plots
python main.py analyze  --ticker AAPL     # full AI agent analysis (--model, --refresh)
python main.py pipeline --ticker AAPL     # download -> features -> train -> predict
```

### Dashboard

```bash
streamlit run dashboard/app.py
```

Pick a ticker in the sidebar; if it hasn't been trained yet, the dashboard downloads
the data and trains the model on demand (a few seconds).

---

## How the XGBoost Model Works

The predictor frames "will the price go up tomorrow?" as a **binary classification**
problem. For each trading day we compute a set of technical indicators (momentum,
trend, volatility, and volume) and attach a **label**: `1` (BUY) if the *next* day's
close is higher than today's, otherwise `0` (SELL). The model never sees tomorrow's
price as an input — only today's indicators — so it must learn patterns that *precede*
up-moves.

**XGBoost** (Extreme Gradient Boosting) builds an ensemble of small decision trees,
one after another. Each new tree focuses on the rows the current ensemble gets wrong,
nudging predictions in the right direction (gradient descent on the loss). With 200
shallow trees, a small learning rate, and column/row subsampling, it captures
non-linear interactions between indicators (e.g. "high RSI *and* price at the upper
Bollinger band") that a single tree or a linear model would miss — while the
regularization and subsampling guard against overfitting.

Crucially, the train/test split is **chronological**: the first 80% of dates train the
model and the most recent 20% test it. A random shuffle would let the model "peek" at
future days during training and produce dishonestly high accuracy. We deliberately
avoid that (see `src/preprocess.py`).

At prediction time, `predict.py` loads the saved model, takes the **latest** row of
indicators, and returns `{signal, confidence}` where confidence is the model's
probability for the chosen class.

---

## How the AI Agent Works

The agent layer turns raw numbers into a readable explanation. Flow:

```mermaid
flowchart TD
    A[predict.py: signal + confidence] --> P[prompt_builder.py]
    B[processed_data.csv: latest indicators] --> P
    C[news_fetcher.py: headlines] --> S[sentiment.py: VADER]
    S --> P
    P -->|structured prompt| O[openrouter_client.py]
    O -->|LLM completion| M[market_analyzer.py]
    M -->|Markdown + disclaimer| UI[Streamlit / CLI]
    M --> CH[ai_chat.py grounding]
```

1. **`news_fetcher.py`** pulls recent headlines (NewsAPI if a key is set, else DuckDuckGo).
2. **`sentiment.py`** scores them with VADER → bullish / bearish / neutral + a compound score.
3. **`prompt_builder.py`** converts indicators into plain-English states and assembles a
   structured prompt (with guardrails: concise, educational, no financial advice).
4. **`openrouter_client.py`** calls the LLM (retry with exponential backoff on 429/5xx).
5. **`market_analyzer.py`** orchestrates everything, caches the result by
   `(ticker, date, model)`, and guarantees the educational disclaimer is appended.
6. **`ai_chat.py`** reuses the same context to answer follow-up questions in the dashboard.

> **Note on sentiment:** VADER is a general-purpose lexicon model, so finance jargon
> ("smashes earnings", "recall") can be mislabeled. The prompt explicitly instructs the
> LLM to treat sentiment as a weak, noisy signal. FinBERT is listed below as the upgrade path.

---

## Screenshots

> Replace these placeholders with real screenshots after running the dashboard.

![Dashboard](docs/dashboard.png)
![Prediction Card](docs/prediction_card.png)
![AI Analysis](docs/ai_analysis.png)

Evaluation plots are generated automatically into `docs/` by `python main.py evaluate --ticker AAPL`:

![Confusion Matrix](docs/AAPL_confusion.png)
![Feature Importance](docs/AAPL_feature_importance.png)

---

## Accuracy & Limitations

**Be realistic: this is an educational tool, not a money printer.** Predicting the
*direction* of a single stock one day ahead is close to a coin flip. Published and
practitioner results for this kind of daily classifier typically land around
**52–58% accuracy** — only slightly better than chance.

**What we actually observed on AAPL.** The §5.4 model overfits hard: it scores
**99.6% on the training data** but only **~47% on the held-out test set** at the default
0.5 threshold — a ~0.52 train/test gap. That is **not a data leak** (leakage shows up as
suspiciously *high test* accuracy, e.g. >75%); it is classic overfitting plus the genuine
difficulty of next-day direction. At 0.5 the model also degenerated into predicting mostly
SELL (recall 0.19), so it underperformed the ~54% "always-BUY" baseline.

**The fix shipped in this repo.** Rather than change the spec hyperparameters, the pipeline
tunes the **decision threshold** on a chronological validation slice carved from the
*training* data (never the test set) and stores it in the model bundle. For AAPL this
selects `P(BUY) ≥ 0.30`, which rebalances predictions and lifts the test set to:

| Metric (AAPL test) | Default 0.5 | Tuned threshold 0.30 |
|--------------------|-------------|----------------------|
| Accuracy           | 0.471       | **0.537** |
| Recall (BUY)       | 0.189       | **0.599** |
| F1 (BUY)           | 0.281       | **0.585** |

This brings the model to roughly the majority-class baseline with **balanced** predictions
(it now calls both BUY and SELL) — an honest improvement in usefulness, **not** evidence of
a real market edge. Beating the baseline meaningfully would require reducing overfitting
(regularization) and/or adding signal beyond technicals.

Known limitations:

- **Markets are near-efficient and noisy.** Technical indicators alone carry weak
  predictive signal for next-day direction.
- **Overfitting.** The spec's 200 depth-6 trees memorize the training data; regularization
  (shallower trees, L1/L2) is the natural next lever and is left as a documented follow-up.
- **No fundamentals, macro, or order-flow data** — only price/volume-derived features.
- **VADER sentiment is not finance-tuned** and can mislabel headlines.
- **No transaction costs or slippage** are modeled — paper signals only.

Treat the output as a *learning aid* for how ML pipelines and LLM agents fit together,
**not** as investment guidance.

---

## Future Improvements

- Real-time prediction via WebSocket (yfinance live or Alpaca paper trading)
- Multi-stock portfolio dashboard with allocation suggestions
- Reinforcement-learning agent for position sizing
- FinBERT-based sentiment instead of VADER
- Telegram / Discord alert bot for new signals
- Voice assistant front-end (Whisper + TTS)
- Multi-agent architecture (researcher + analyst + risk-manager agents)
- Backtesting engine with realistic transaction costs
- Auto-generated daily PDF reports
- Streaming news ingestion (Server-Sent Events)

---

## Disclaimer & License

> ⚠️ **This tool is for educational and academic purposes only.** Predictions are
> generated by a machine learning model and an AI language model; they are not financial
> advice. Past performance does not guarantee future results. Do your own research before
> making investment decisions.

**License:** MIT — see below.

```
MIT License

Copyright (c) 2026

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
