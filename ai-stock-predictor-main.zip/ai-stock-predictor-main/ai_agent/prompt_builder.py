"""Compose the structured analyst prompt (§6.4).

Translates raw indicator values into plain-English "states" (e.g. MACD bullish,
price near the upper Bollinger band) and assembles a system+user message pair
for the OpenRouter chat API. The system message encodes the guardrails (concise,
educational, no financial advice) and the mandatory closing disclaimer.
"""

from __future__ import annotations

from typing import Any, Mapping

from src.utils import ANALYSIS_DISCLAIMER, enable_utf8_console

_SYSTEM_PROMPT: str = (
    "You are a financial market analyst. Provide a CONCISE, EDUCATIONAL analysis "
    "of at most 150 words. You do NOT give financial advice or guarantees, and "
    "you never promise returns. Treat the news-sentiment score as a weak, noisy "
    "signal (it comes from a general-purpose model, not a finance-tuned one). "
    f'Always end your reply with exactly this line: "{ANALYSIS_DISCLAIMER}"'
)


def build_indicator_states(row: Mapping[str, Any]) -> dict[str, str]:
    """Convert numeric indicators into human-readable states.

    Args:
        row: Mapping with the latest values for ``rsi_14``, ``macd_diff``,
            ``sma_20``, ``sma_50``, ``bb_pband``, ``volume_pct_change``.

    Returns:
        dict: Readable strings for ``rsi``, ``macd_state``, ``sma_state``,
        ``bb_state``, ``vol_change``.
    """
    rsi = float(row.get("rsi_14", 0.0))
    if rsi >= 70:
        rsi_state = f"{rsi:.1f} (overbought)"
    elif rsi <= 30:
        rsi_state = f"{rsi:.1f} (oversold)"
    else:
        rsi_state = f"{rsi:.1f} (neutral)"

    macd_diff = float(row.get("macd_diff", 0.0))
    macd_state = (
        "bullish (MACD above signal)" if macd_diff > 0 else "bearish (MACD below signal)"
    )

    sma_20 = float(row.get("sma_20", 0.0))
    sma_50 = float(row.get("sma_50", 0.0))
    sma_state = (
        "SMA20 above SMA50 (uptrend)" if sma_20 > sma_50 else "SMA20 below SMA50 (downtrend)"
    )

    pband = float(row.get("bb_pband", 0.5))
    if pband > 1.0:
        bb_state = "above upper band (overbought)"
    elif pband < 0.0:
        bb_state = "below lower band (oversold)"
    elif pband >= 0.8:
        bb_state = "near upper band"
    elif pband <= 0.2:
        bb_state = "near lower band"
    else:
        bb_state = "mid-band"

    vol_change = f"{float(row.get('volume_pct_change', 0.0)) * 100:.1f}"

    return {
        "rsi": rsi_state,
        "macd_state": macd_state,
        "sma_state": sma_state,
        "bb_state": bb_state,
        "vol_change": vol_change,
    }


def build_prompt_text(
    ticker: str,
    close: float,
    states: Mapping[str, str],
    prediction: Mapping[str, Any],
    sentiment: Mapping[str, Any],
    headlines: list[str],
) -> str:
    """Build the user-message body following the §6.4 template.

    Args:
        ticker: Stock symbol.
        close: Latest close price.
        states: Output of :func:`build_indicator_states`.
        prediction: ``{signal, confidence, ...}`` from ``predict_latest``.
        sentiment: ``{overall_label, overall_score, ...}`` from ``score_news``.
        headlines: Up to three headline strings.

    Returns:
        str: The formatted prompt body.
    """
    conf_pct = f"{float(prediction.get('confidence', 0.0)) * 100:.0f}"
    top = headlines[:3] if headlines else ["(no recent headlines found)"]
    headline_block = "\n".join(f"- {h}" for h in top)

    return (
        f"Stock: {ticker}\n"
        f"Latest Close: {close:.2f}\n"
        f"RSI (14): {states['rsi']}\n"
        f"MACD: {states['macd_state']}\n"
        f"SMA(20) vs SMA(50): {states['sma_state']}\n"
        f"Bollinger position: {states['bb_state']}\n"
        f"Volume change: {states['vol_change']}%\n\n"
        f"Model prediction: {prediction.get('signal')} (confidence {conf_pct}%)\n\n"
        f"Recent news sentiment: {sentiment.get('overall_label')} "
        f"(score {sentiment.get('overall_score')})\n"
        f"Top headlines:\n{headline_block}\n\n"
        "Task:\n"
        f"1. Explain in 3-4 sentences WHY the model likely predicted "
        f"{prediction.get('signal')}.\n"
        "2. Note one bullish factor and one bearish factor.\n"
        "3. End with a one-line educational caveat."
    )


def build_analysis_messages(
    ticker: str,
    close: float,
    states: Mapping[str, str],
    prediction: Mapping[str, Any],
    sentiment: Mapping[str, Any],
    headlines: list[str],
) -> list[dict[str, str]]:
    """Assemble the system+user messages for the chat API.

    Returns:
        list: ``[{role: system, ...}, {role: user, ...}]``.
    """
    user = build_prompt_text(ticker, close, states, prediction, sentiment, headlines)
    return [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": user},
    ]


if __name__ == "__main__":
    enable_utf8_console()
    # Smoke test: build a prompt from mock data (no network).
    mock_row = {
        "rsi_14": 78.6,
        "macd_diff": 0.99,
        "sma_20": 300.0,
        "sma_50": 280.0,
        "bb_pband": 0.89,
        "volume_pct_change": 0.12,
    }
    states = build_indicator_states(mock_row)
    msgs = build_analysis_messages(
        ticker="AAPL",
        close=308.82,
        states=states,
        prediction={"signal": "SELL", "confidence": 0.83},
        sentiment={"overall_label": "bullish", "overall_score": 0.204},
        headlines=["Apple hits 52-week high", "Analysts split on valuation", "iPhone 18 leaks"],
    )
    print("Indicator states:", states)
    print("\n--- SYSTEM ---\n", msgs[0]["content"])
    print("\n--- USER ---\n", msgs[1]["content"])
    assert len(msgs) == 2 and msgs[0]["role"] == "system"
    print("\nprompt_builder.py smoke test passed")
