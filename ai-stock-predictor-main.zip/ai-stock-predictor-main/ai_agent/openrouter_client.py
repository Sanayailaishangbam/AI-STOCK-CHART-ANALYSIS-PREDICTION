"""Thin OpenRouter chat client (§6.3).

POSTs to the OpenRouter chat-completions endpoint and returns only the
assistant's text content. Retries on transient failures (HTTP 429 and 5xx, plus
connection/timeout errors) with exponential backoff (1s → 2s → 4s, max 3
retries); other 4xx errors (auth, bad request, missing model) fail fast so
mistakes surface immediately instead of being retried.

The API key is read from ``.env`` via ``python-dotenv`` and never hardcoded.
"""

from __future__ import annotations

import os
import time
from typing import Optional, Union

import requests
from dotenv import load_dotenv

from src.utils import DEFAULT_LLM_MODEL, enable_utf8_console, get_logger, get_project_root

logger = get_logger(__name__)

# Load .env from the project root so OPENROUTER_API_KEY is available.
load_dotenv(get_project_root() / ".env")

#: OpenRouter chat-completions endpoint (§6.3).
OPENROUTER_URL: str = "https://openrouter.ai/api/v1/chat/completions"

#: Transient HTTP statuses worth retrying. Note 429 is included; other 4xx are not.
RETRYABLE_STATUS: frozenset[int] = frozenset({429, 500, 502, 503, 504})

DEFAULT_TIMEOUT: int = 30
DEFAULT_MAX_RETRIES: int = 3
DEFAULT_BASE_DELAY: float = 1.0

#: A message is a ``{"role": ..., "content": ...}`` dict; callers may also pass a
#: bare string which is wrapped as a single user message.
Messages = Union[str, list[dict[str, str]]]


class OpenRouterError(RuntimeError):
    """Raised when an OpenRouter request fails non-transiently or exhausts retries."""


class OpenRouterClient:
    """Minimal client for OpenRouter chat completions.

    Args:
        api_key: API key; falls back to ``OPENROUTER_API_KEY`` from the env/.env.
        model: Default model id; falls back to ``DEFAULT_LLM_MODEL`` env or the
            project default ``deepseek/deepseek-chat``.
        timeout: Per-request timeout in seconds.
        max_retries: Max retries for transient failures (total tries = retries+1).
        base_delay: Base backoff delay in seconds (doubles each retry).
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        timeout: int = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        base_delay: float = DEFAULT_BASE_DELAY,
    ) -> None:
        # Strip whitespace defensively — a trailing newline in .env causes 401s.
        raw_key = api_key if api_key is not None else os.getenv("OPENROUTER_API_KEY")
        self.api_key: Optional[str] = raw_key.strip() if raw_key else None
        self.model: str = model or os.getenv("DEFAULT_LLM_MODEL") or DEFAULT_LLM_MODEL
        self.timeout = timeout
        self.max_retries = max_retries
        self.base_delay = base_delay

    def has_key(self) -> bool:
        """Return True if an API key is configured."""
        return bool(self.api_key)

    def _headers(self) -> dict[str, str]:
        """Build request headers (Bearer auth + OpenRouter ranking hints)."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://localhost",
            "X-Title": "AI Stock Predictor",
        }

    @staticmethod
    def _normalize(messages: Messages) -> list[dict[str, str]]:
        """Coerce a string prompt into a one-element user-message list."""
        if isinstance(messages, str):
            return [{"role": "user", "content": messages}]
        return messages

    def chat(
        self,
        messages: Messages,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 512,
    ) -> str:
        """Send a chat-completion request and return only the assistant text.

        Args:
            messages: Either a prompt string or a list of role/content dicts.
            model: Override the default model for this call.
            temperature: Sampling temperature.
            max_tokens: Maximum tokens in the completion.

        Returns:
            str: The assistant message content (``choices[0].message.content``).

        Raises:
            OpenRouterError: On missing key, non-retryable HTTP error, malformed
                response, or exhausted retries.
        """
        if not self.api_key:
            raise OpenRouterError(
                "OPENROUTER_API_KEY is not set. Add it to .env (no quotes / spaces)."
            )

        payload = {
            "model": model or self.model,
            "messages": self._normalize(messages),
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        last_error: Optional[str] = None
        for attempt in range(self.max_retries + 1):
            try:
                response = requests.post(
                    OPENROUTER_URL,
                    headers=self._headers(),
                    json=payload,
                    timeout=self.timeout,
                )
            except (requests.ConnectionError, requests.Timeout) as exc:
                last_error = f"network error: {exc}"
                if attempt < self.max_retries:
                    self._backoff(attempt, last_error)
                    continue
                raise OpenRouterError(
                    f"Request failed after {self.max_retries} retries ({last_error})."
                ) from exc

            if response.status_code == 200:
                return self._extract_content(response)

            if response.status_code in RETRYABLE_STATUS and attempt < self.max_retries:
                self._backoff(attempt, f"HTTP {response.status_code}")
                continue

            # Non-retryable (e.g. 401/402/404/400) or retries exhausted → fail fast.
            raise OpenRouterError(
                f"OpenRouter request failed: HTTP {response.status_code} — "
                f"{response.text[:300]}"
            )

        raise OpenRouterError(f"Request failed after retries ({last_error}).")

    def _backoff(self, attempt: int, reason: str) -> None:
        """Sleep with exponential backoff before the next retry.

        Args:
            attempt: Zero-based index of the just-failed attempt (0 → 1s, 1 → 2s, ...).
            reason: Human-readable cause, for logging.
        """
        delay = self.base_delay * (2 ** attempt)
        logger.warning("Retrying after %.0fs (attempt %d, %s)", delay, attempt + 1, reason)
        time.sleep(delay)

    @staticmethod
    def _extract_content(response: requests.Response) -> str:
        """Parse the assistant text out of a 200 response, raising on bad shape."""
        try:
            data = response.json()
            return data["choices"][0]["message"]["content"].strip()
        except (ValueError, KeyError, IndexError, TypeError) as exc:
            raise OpenRouterError(
                f"Unexpected OpenRouter response shape: {response.text[:300]}"
            ) from exc

    def ping(self, model: Optional[str] = None) -> str:
        """Send a trivial prompt to verify connectivity/auth.

        Returns:
            str: The model's reply (expected to contain ``PONG``).
        """
        return self.chat(
            "Reply with the word PONG and nothing else.",
            model=model,
            temperature=0.0,
            max_tokens=10,
        )


def chat(messages: Messages, model: Optional[str] = None, **kwargs: object) -> str:
    """Module-level convenience: one-shot chat using a default client.

    Args:
        messages: Prompt string or list of role/content dicts.
        model: Optional model override.
        **kwargs: Forwarded to :meth:`OpenRouterClient.chat`.

    Returns:
        str: The assistant text content.
    """
    return OpenRouterClient(model=model).chat(messages, **kwargs)  # type: ignore[arg-type]


if __name__ == "__main__":
    enable_utf8_console()
    client = OpenRouterClient()
    print("Endpoint    :", OPENROUTER_URL)
    print("Model       :", client.model)
    print("Timeout     :", client.timeout, "s")
    print("Max retries :", client.max_retries, "(backoff 1s -> 2s -> 4s)")
    print("API key set :", client.has_key())

    if not client.has_key():
        print(
            "\nOPENROUTER_API_KEY not found in .env — live ping blocked.\n"
            "Add a key to .env to run the real ping."
        )
    else:
        print("\nLive ping ->")
        reply = client.ping()
        print("  raw reply:", repr(reply))
        print("\nopenrouter_client.py live smoke test passed ✔")
