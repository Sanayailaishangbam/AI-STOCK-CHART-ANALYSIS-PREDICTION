"""News sentiment scoring with VADER (§6.3).

Uses ``vaderSentiment`` (not TextBlob) to score headline text and maps VADER's
compound score to a finance-friendly label: bullish / bearish / neutral, each
with an emoji chip for the dashboard (🟢 / 🔴 / ⚪).

VADER is a lexicon/rule-based, deterministic model — no network or training
needed — so these functions are fast and reproducible.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer

from src.utils import enable_utf8_console, get_logger

logger = get_logger(__name__)

#: Standard VADER thresholds for classifying the compound score.
_POSITIVE_THRESHOLD: float = 0.05
_NEGATIVE_THRESHOLD: float = -0.05

#: Emoji chips used in the dashboard news section (§7.1).
_CHIPS: dict[str, str] = {"bullish": "🟢", "bearish": "🔴", "neutral": "⚪"}

# A single shared analyzer instance (loading the lexicon is the only cost).
_analyzer = SentimentIntensityAnalyzer()


@dataclass
class SentimentResult:
    """A single sentiment score.

    Attributes:
        compound: VADER compound score in [-1, 1].
        label: ``"bullish"`` / ``"bearish"`` / ``"neutral"``.
        chip: Emoji chip matching the label.
    """

    compound: float
    label: str
    chip: str


def label_from_compound(compound: float) -> str:
    """Map a VADER compound score to a sentiment label.

    Args:
        compound: VADER compound score in [-1, 1].

    Returns:
        str: ``"bullish"`` (>= 0.05), ``"bearish"`` (<= -0.05), else ``"neutral"``.
    """
    if compound >= _POSITIVE_THRESHOLD:
        return "bullish"
    if compound <= _NEGATIVE_THRESHOLD:
        return "bearish"
    return "neutral"


def analyze_text(text: str) -> SentimentResult:
    """Score a single piece of text with VADER.

    Args:
        text: The headline or sentence to score.

    Returns:
        SentimentResult: Compound score, label, and emoji chip.
    """
    compound = float(_analyzer.polarity_scores(text or "")["compound"])
    label = label_from_compound(compound)
    return SentimentResult(compound=round(compound, 4), label=label, chip=_CHIPS[label])


def score_news(items: list[dict[str, Any]]) -> dict[str, Any]:
    """Score a list of news items and compute an overall sentiment.

    Each item is scored on its title plus summary. The overall score is the mean
    of per-item compound scores (0.0 / neutral if the list is empty).

    Args:
        items: News dicts, each with ``title`` and optional ``summary``.

    Returns:
        dict: ``{overall_score, overall_label, overall_chip, items}`` where
        ``items`` is the input list with ``compound``, ``label``, and ``chip``
        added to each entry.
    """
    annotated: list[dict[str, Any]] = []
    compounds: list[float] = []

    for item in items:
        text = f"{item.get('title', '')}. {item.get('summary', '')}".strip()
        result = analyze_text(text)
        enriched = {**item, "compound": result.compound, "label": result.label, "chip": result.chip}
        annotated.append(enriched)
        compounds.append(result.compound)

    overall_score = round(sum(compounds) / len(compounds), 4) if compounds else 0.0
    overall_label = label_from_compound(overall_score)

    logger.info(
        "Scored %d headlines -> overall %s (%.3f)",
        len(items),
        overall_label,
        overall_score,
    )
    return {
        "overall_score": overall_score,
        "overall_label": overall_label,
        "overall_chip": _CHIPS[overall_label],
        "items": annotated,
    }


if __name__ == "__main__":
    enable_utf8_console()
    samples = [
        "Apple smashes earnings expectations, stock soars to record high",
        "Tesla recalls thousands of cars amid safety probe, shares tumble",
        "Microsoft holds annual shareholder meeting on Tuesday",
    ]
    print("Per-headline sentiment:")
    for s in samples:
        r = analyze_text(s)
        print(f"  {r.chip} {r.label:<8} ({r.compound:+.3f})  {s[:55]}")

    news = [{"title": t, "summary": ""} for t in samples]
    overall = score_news(news)
    print(
        f"\nOverall: {overall['overall_chip']} {overall['overall_label']} "
        f"({overall['overall_score']:+.3f})"
    )
    assert {i["label"] for i in overall["items"]} <= {"bullish", "bearish", "neutral"}
    print("\nsentiment.py smoke test passed ✔")
