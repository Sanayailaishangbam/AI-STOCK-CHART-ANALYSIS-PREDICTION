"""Fetch recent stock news (§6.3).

Prefers the NewsAPI free tier when ``NEWS_API_KEY`` is set; otherwise falls back
to DuckDuckGo news search via the ``ddgs`` package (no key required). Both paths
return a uniform list of ``{title, summary, url, source, date}`` dicts. All
network calls are wrapped so a failure degrades gracefully to an empty list
rather than crashing the dashboard.
"""

from __future__ import annotations

import os
from typing import Any, Optional

import requests
from dotenv import load_dotenv

from src.utils import enable_utf8_console, get_logger, get_project_root

logger = get_logger(__name__)

load_dotenv(get_project_root() / ".env")

NEWSAPI_URL: str = "https://newsapi.org/v2/everything"
_REQUEST_TIMEOUT: int = 15

#: Friendlier search queries than bare tickers (improves headline relevance).
_COMPANY_NAMES: dict[str, str] = {
    "AAPL": "Apple",
    "TSLA": "Tesla",
    "MSFT": "Microsoft",
    "AMZN": "Amazon",
    "GOOG": "Google",
}


def _build_query(ticker: str) -> str:
    """Build a news search query for a ticker (company name + 'stock')."""
    name = _COMPANY_NAMES.get(ticker.upper(), ticker.upper())
    return f"{name} stock"


def _fetch_newsapi(query: str, max_results: int, api_key: str) -> list[dict[str, Any]]:
    """Fetch news via the NewsAPI ``/everything`` endpoint.

    Args:
        query: Search query.
        max_results: Maximum number of articles to return.
        api_key: NewsAPI key.

    Returns:
        list: Uniform news dicts. Empty on any failure.
    """
    params = {
        "q": query,
        "pageSize": max_results,
        "sortBy": "publishedAt",
        "language": "en",
        "apiKey": api_key,
    }
    try:
        resp = requests.get(NEWSAPI_URL, params=params, timeout=_REQUEST_TIMEOUT)
        resp.raise_for_status()
        articles = resp.json().get("articles", [])
    except Exception as exc:
        logger.warning("NewsAPI fetch failed (%s); will fall back to DuckDuckGo.", exc)
        return []

    return [
        {
            "title": a.get("title", ""),
            "summary": a.get("description", "") or "",
            "url": a.get("url", ""),
            "source": (a.get("source") or {}).get("name", "NewsAPI"),
            "date": a.get("publishedAt", ""),
        }
        for a in articles
    ]


def _fetch_duckduckgo(query: str, max_results: int) -> list[dict[str, Any]]:
    """Fetch news via DuckDuckGo (``ddgs``) — no API key required.

    Args:
        query: Search query.
        max_results: Maximum number of articles to return.

    Returns:
        list: Uniform news dicts. Empty on any failure.
    """
    try:
        from ddgs import DDGS

        with DDGS() as ddgs:
            results = ddgs.news(query, region="us-en", safesearch="off", max_results=max_results)
    except Exception as exc:
        logger.warning("DuckDuckGo news fetch failed: %s", exc)
        return []

    return [
        {
            "title": r.get("title", ""),
            "summary": r.get("body", "") or "",
            "url": r.get("url", ""),
            "source": r.get("source", "DuckDuckGo"),
            "date": r.get("date", ""),
        }
        for r in results
    ]


def fetch_news(
    ticker: str, max_results: int = 5, query: Optional[str] = None
) -> list[dict[str, Any]]:
    """Fetch recent news headlines for a ticker.

    Uses NewsAPI when a key is configured (falling back to DuckDuckGo if that
    request fails or returns nothing), otherwise DuckDuckGo directly.

    Args:
        ticker: Stock symbol, e.g. ``"AAPL"``.
        max_results: Maximum number of headlines to return.
        query: Optional explicit search query (overrides the default).

    Returns:
        list: News dicts ``{title, summary, url, source, date}`` (possibly empty).
    """
    search = query or _build_query(ticker)
    api_key = os.getenv("NEWS_API_KEY")
    api_key = api_key.strip() if api_key else None

    items: list[dict[str, Any]] = []
    if api_key:
        logger.info("Fetching news for %s via NewsAPI", ticker)
        items = _fetch_newsapi(search, max_results, api_key)

    if not items:
        logger.info("Fetching news for %s via DuckDuckGo", ticker)
        items = _fetch_duckduckgo(search, max_results)

    # Drop entries with an empty title (occasionally returned by DDG).
    items = [i for i in items if i.get("title")]
    logger.info("Retrieved %d headlines for %s", len(items), ticker)
    return items[:max_results]


if __name__ == "__main__":
    enable_utf8_console()
    provider = "NewsAPI" if os.getenv("NEWS_API_KEY") else "DuckDuckGo (no NEWS_API_KEY)"
    print("Provider:", provider)

    headlines = fetch_news("AAPL", max_results=5)
    print(f"\nFetched {len(headlines)} headlines for AAPL:\n")
    for i, h in enumerate(headlines, 1):
        print(f"  {i}. {h['title'][:70]}")
        print(f"     source={h['source']}  url={h['url'][:60]}")

    assert len(headlines) >= 3, "Expected at least 3 headlines (§15 requirement)"
    print("\nnews_fetcher.py smoke test passed ✔")
