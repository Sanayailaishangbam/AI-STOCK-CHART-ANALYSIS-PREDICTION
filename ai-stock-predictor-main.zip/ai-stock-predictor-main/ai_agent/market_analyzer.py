"""Orchestrate the AI market analysis (§6.3).

Pulls the latest prediction, indicator states, and scored news, builds the
§6.4 prompt, calls OpenRouter, and returns a Markdown analysis. Responses are
cached on disk by ``(ticker, date, model)`` under ``data/.cache/`` so repeated
dev runs do not burn API credits. Every analysis is guaranteed to end with the
mandatory educational disclaimer (§6.5).
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from ai_agent.openrouter_client import OpenRouterClient, OpenRouterError
from ai_agent.news_fetcher import fetch_news
from ai_agent.prompt_builder import build_analysis_messages, build_indicator_states
from ai_agent.sentiment import score_news
from src.features import load_processed_data
from src.predict import predict_latest
from src.utils import (
    ANALYSIS_DISCLAIMER,
    DEFAULT_LLM_MODEL,
    cache_dir,
    enable_utf8_console,
    get_logger,
)

logger = get_logger(__name__)


def _cache_path(ticker: str, date: str, model: str) -> Path:
    """Build the on-disk cache path for one analysis result."""
    safe_model = model.replace("/", "_").replace(":", "_")
    return cache_dir() / f"analysis_{ticker.upper()}_{date}_{safe_model}.json"


def _ensure_disclaimer(text: str) -> str:
    """Append the educational disclaimer if the model omitted it (§6.5)."""
    if ANALYSIS_DISCLAIMER.lower() in text.lower():
        return text.strip()
    return f"{text.strip()}\n\n_{ANALYSIS_DISCLAIMER}_"


def analyze_market(
    ticker: str,
    model: Optional[str] = None,
    max_news: int = 5,
    force_refresh: bool = False,
    client: Optional[OpenRouterClient] = None,
) -> dict[str, Any]:
    """Generate (or load from cache) a full AI market analysis for a ticker.

    Args:
        ticker: Stock symbol with a trained model and processed data available.
        model: LLM model id (defaults to the client's / project default).
        max_news: Number of headlines to fetch and score.
        force_refresh: If True, ignore any cached result and call the API.
        client: Optional pre-built :class:`OpenRouterClient`.

    Returns:
        dict: ``{ticker, date, signal, confidence, close, indicator_states,
        sentiment, headlines, analysis, model, cached}``.

    Raises:
        OpenRouterError: If the API call fails and no cache is available.
    """
    ticker = ticker.upper()
    client = client or OpenRouterClient(model=model)
    model = model or client.model

    # 1) Prediction + latest indicator row (single source of truth: src.*).
    prediction = predict_latest(ticker)
    date = prediction["date"]
    processed = load_processed_data(ticker)
    latest_row = processed.iloc[-1].to_dict()

    cache_file = _cache_path(ticker, date, model)
    if not force_refresh and cache_file.exists():
        try:
            cached = json.loads(cache_file.read_text(encoding="utf-8"))
            cached["cached"] = True
            logger.info("Loaded cached analysis <- %s", cache_file)
            return cached
        except (OSError, ValueError) as exc:
            logger.warning("Cache read failed (%s); regenerating.", exc)

    # 2) News + sentiment.
    headlines = fetch_news(ticker, max_results=max_news)
    sentiment = score_news(headlines)

    # 3) Build prompt and call the LLM.
    states = build_indicator_states(latest_row)
    messages = build_analysis_messages(
        ticker=ticker,
        close=prediction["close"],
        states=states,
        prediction=prediction,
        sentiment=sentiment,
        headlines=[h["title"] for h in headlines],
    )

    logger.info("Requesting AI analysis for %s (model=%s)", ticker, model)
    raw = client.chat(messages, model=model, temperature=0.5, max_tokens=320)
    analysis = _ensure_disclaimer(raw)

    result: dict[str, Any] = {
        "ticker": ticker,
        "date": date,
        "signal": prediction["signal"],
        "confidence": prediction["confidence"],
        "close": prediction["close"],
        "indicator_states": states,
        "sentiment": sentiment,
        "headlines": headlines,
        "analysis": analysis,
        "model": model,
        "cached": False,
    }

    # 4) Persist to cache.
    try:
        cache_file.write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
        logger.info("Cached analysis -> %s", cache_file)
    except OSError as exc:
        logger.warning("Could not write cache %s: %s", cache_file, exc)

    return result


if __name__ == "__main__":
    enable_utf8_console()
    # Smoke test: first call hits the API; second call should hit the cache.
    result = analyze_market("AAPL", force_refresh=True)
    print("Ticker     :", result["ticker"], "|", result["date"])
    print("Prediction :", result["signal"], f"({result['confidence'] * 100:.0f}%)")
    print("Sentiment  :", result["sentiment"]["overall_chip"], result["sentiment"]["overall_label"])
    print("Headlines  :", len(result["headlines"]))
    print("Cached     :", result["cached"])
    print("\n--- AI ANALYSIS ---\n")
    print(result["analysis"])

    assert ANALYSIS_DISCLAIMER.lower() in result["analysis"].lower(), "Disclaimer missing!"

    print("\n--- Re-run (expect cache hit) ---")
    again = analyze_market("AAPL")
    print("Cached on second call:", again["cached"])
    assert again["cached"] is True
    print("\nmarket_analyzer.py smoke test passed ✔")
