"""AI agent layer: OpenRouter client, news, sentiment, analysis, and chat."""

__version__ = "0.1.0"
