"""Conversational chat assistant (§6.3 / §6.5).

Maintains a short rolling message history and calls OpenRouter for each turn.
Replies are kept concise (<= 80 words) and educational — never financial advice.
The assistant can be grounded with the current market context (prediction,
indicator states, news sentiment) so questions like "Why this prediction?" are
answered against the real dashboard state rather than in the abstract.
"""

from __future__ import annotations

from typing import Any, Optional

from ai_agent.openrouter_client import OpenRouterClient
from src.utils import ANALYSIS_DISCLAIMER, enable_utf8_console, get_logger

logger = get_logger(__name__)

_BASE_SYSTEM_PROMPT: str = (
    "You are a friendly stock-market educator embedded in an analytics dashboard. "
    "Answer in plain English in at most 80 words, no jargon dumps, beginner-friendly. "
    "You do NOT give financial advice, price targets, or guarantees. If market "
    "context is provided below, use it to ground your answer; otherwise answer the "
    "general question helpfully."
)

#: Default number of past messages (user+assistant) retained in history.
_DEFAULT_MAX_HISTORY: int = 10


class AIChat:
    """A small stateful chat wrapper around :class:`OpenRouterClient`.

    Args:
        client: Optional pre-built client (one is created if omitted).
        model: Optional model override.
        context: Optional market-context string to ground replies.
        max_history: Max number of past messages to keep (older ones dropped).
    """

    def __init__(
        self,
        client: Optional[OpenRouterClient] = None,
        model: Optional[str] = None,
        context: Optional[str] = None,
        max_history: int = _DEFAULT_MAX_HISTORY,
    ) -> None:
        self.client = client or OpenRouterClient(model=model)
        self.model = model or self.client.model
        self.context: Optional[str] = context
        self.max_history = max_history
        self.history: list[dict[str, str]] = []

    def reset(self) -> None:
        """Clear the conversation history (keeps the context grounding)."""
        self.history = []

    def set_context(self, context: Optional[str]) -> None:
        """Set/replace the market-context grounding string."""
        self.context = context

    @staticmethod
    def context_from_analysis(result: dict[str, Any]) -> str:
        """Build a grounding context string from a ``market_analyzer`` result.

        Args:
            result: The dict returned by ``analyze_market``.

        Returns:
            str: A compact context block describing the current state.
        """
        states = result.get("indicator_states", {})
        sentiment = result.get("sentiment", {})
        return (
            f"Ticker: {result.get('ticker')} (as of {result.get('date')})\n"
            f"Latest close: {result.get('close')}\n"
            f"Model prediction: {result.get('signal')} "
            f"(confidence {float(result.get('confidence', 0)) * 100:.0f}%)\n"
            f"RSI: {states.get('rsi')}\n"
            f"MACD: {states.get('macd_state')}\n"
            f"Trend: {states.get('sma_state')}\n"
            f"Bollinger: {states.get('bb_state')}\n"
            f"News sentiment: {sentiment.get('overall_label')} "
            f"(score {sentiment.get('overall_score')})"
        )

    def _system_message(self) -> dict[str, str]:
        """Compose the system message, including context if present."""
        content = _BASE_SYSTEM_PROMPT
        if self.context:
            content += f"\n\nCurrent market context:\n{self.context}"
        return {"role": "system", "content": content}

    def _trim(self) -> None:
        """Drop the oldest messages so history stays within ``max_history``."""
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history :]

    def ask(self, message: str) -> str:
        """Send a user message and return the assistant's reply.

        The user message and assistant reply are appended to the rolling history.

        Args:
            message: The user's question.

        Returns:
            str: The assistant's reply (<= ~80 words), or a friendly error string
            if the API call fails.
        """
        self.history.append({"role": "user", "content": message})
        self._trim()

        messages = [self._system_message(), *self.history]
        try:
            reply = self.client.chat(messages, model=self.model, temperature=0.6, max_tokens=200)
        except Exception as exc:
            logger.warning("Chat request failed: %s", exc)
            return f"Sorry, I couldn't reach the AI service right now ({exc}). {ANALYSIS_DISCLAIMER}"

        self.history.append({"role": "assistant", "content": reply})
        self._trim()
        return reply


if __name__ == "__main__":
    enable_utf8_console()
    # Smoke test: grounded multi-turn chat (two live calls).
    context = AIChat.context_from_analysis(
        {
            "ticker": "AAPL",
            "date": "2026-05-22",
            "close": 308.82,
            "signal": "SELL",
            "confidence": 0.83,
            "indicator_states": {
                "rsi": "78.6 (overbought)",
                "macd_state": "bullish (MACD above signal)",
                "sma_state": "SMA20 above SMA50 (uptrend)",
                "bb_state": "near upper band",
            },
            "sentiment": {"overall_label": "bullish", "overall_score": 0.497},
        }
    )
    chat = AIChat(context=context)

    q1 = "Why this prediction?"
    print(f"Q1: {q1}\nA1: {chat.ask(q1)}\n")

    q2 = "Explain RSI in one sentence."
    print(f"Q2: {q2}\nA2: {chat.ask(q2)}\n")

    print("History length (msgs):", len(chat.history))
    assert len(chat.history) == 4  # 2 user + 2 assistant
    print("\nai_chat.py smoke test passed ✔")
